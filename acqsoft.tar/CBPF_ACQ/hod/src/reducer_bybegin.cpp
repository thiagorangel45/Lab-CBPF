#include <iomanip>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <cstdlib>
#include <iostream>
#include <math.h>
#include <unistd.h>
#include <fstream>
#include <bitset>
#include <vector>

using namespace std;


int main(int argc, char* argv[])
{   
	string acq_date(argv[1]);
	string raw_path="/data/DATA_"+acq_date+"/HOD_RAW/";
	string acq_path="/data/DATA_"+acq_date+"/ACQ.txt";
	string reduced_path="/data/DATA_"+acq_date+"/reduced_bins/";
	fstream auxfile(acq_path, ios_base::in); //open aux text file 
	vector  <string> bin_files;
	string line;
	getline(auxfile,line);  
	bitset<4> ports(line);			//converts the 4 bits from a string of chars to a bitset
	uint8_t selected=ports[0]+ports[1]*2+ports[2]*4+ports[3]*8;
	uint8_t nports=ports[0]+ports[1]+ports[2]+ports[3]; //number of enabled ports
	getline(auxfile,line);
	ulong req_numev=strtoul(line.c_str(),NULL,10);
	cout<<req_numev<<" events were required in the acquisiton"<<endl<<flush;
	cout<<"getting bin files list"<<endl<<flush;
	while(getline(auxfile,line))
	{
		vector  <string> tokens;
		istringstream iss(line);
		string token;
		getline(iss, token, '\t');
		if(strcmp(token.c_str(),"FO")==0)
		{
			getline(iss, token, '\t');
			bin_files.push_back(token);
			cout<<"appending file "<<token<<endl<<flush;
		}
	}
	ulong obt_numev;							 //create variable for obtained number of events
	uint8_t readarray[4114];				 //create array for reading FIFO blocks from file
	//create arrays for bin statistics of frontends in each interface port
	uint64_t bins1[128]={0};
	uint64_t bins2[128]={0};
	uint64_t bins3[128]={0};
	uint64_t bins4[128]={0};
	uint64_t avgbegbin1[64]={0};		
	uint64_t avgbegbin2[64]={0};		
	uint64_t avgbegbin3[64]={0};		
	uint64_t avgbegbin4[64]={0};	
	uint64_t totbegbin1[64]={0};		
	uint64_t totbegbin2[64]={0};
	uint64_t totbegbin3[64]={0};
	uint64_t totbegbin4[64]={0};
	uint64_t total1=0; //create variables for the total of bins with at least one '1' in each port
	uint64_t total2=0;
	uint64_t total3=0;
	uint64_t total4=0; 	

	for (string name : bin_files)
	{
		ifstream bin((raw_path+name), std::ios::binary); //open raw binary file
		if(bin)
		{
			while(true)
			{
				bin.read((char*)readarray,nports*1024+18); //read event block
				if(bin.eof()) //tried to read after end of file
				{
					bin.close();
					bin.clear();
					break;
				}
				obt_numev++;
				if(obt_numev%1731==0) //print progress at every 1731 events
				{
					cout<<obt_numev<<"\r"<<flush;
				}
				int i=0;
				if(ports[0])  //if port is enabled
				{
					uint64_t mask=0xFFFFFFFFFFFFFFFF; //mask used to only counts when pads had their first 1 in the FIFO
					for(int j=0;j<128;j++)			   //read each position in the FIFO
					{
						uint64_t pads=*(uint64_t*)(readarray+j*8); //get the 64 pads	
						pads=pads&mask; //exclude pads that already had 1s counted in a previous FIFO position
						bitset<64> bits(pads);
						int ones=0;
						for(int k=0;k<64;k++)
						{
							ones+=bits[k];
							avgbegbin1[k]+=bits[k]*j;
							totbegbin1[k]+=bits[k];
						}
						mask&=!pads; //turn to 0 all mask bits corresponding to pads that had 1s in this FIFO position
						total1+=ones;
						bins1[j]+=ones;	//increment the number of pads that started having 1s in this bin
					}
					i+=1024;
				}
				if(ports[1]) 
				{
					uint64_t mask=0xFFFFFFFFFFFFFFFF; //mask used to only counts when pads had their first 1 in the FIFO
					for(int j=0;j<128;j++)			   //read each position in the FIFO
					{
						uint64_t pads=*(uint64_t*)(readarray+i+j*8); //get the 64 pads	
						pads=pads&mask; //exclude pads that already had 1s counted in a previous iteration
						bitset<64> bits(pads);
						int ones=0;
						for(int k=0;k<64;k++)
						{
							ones+=bits[k];
							avgbegbin2[k]+=bits[k]*j;
							totbegbin2[k]+=bits[k];
						}
						mask&=!pads; //turn to 0 all mask bits corresponding to pads that had 1s in this FIFO position
						total2+=ones;
						bins2[j]+=ones;	//increment the number of pads that started having 1s in this bin
					}
					i+=1024;
				}
				if(ports[2]) 
				{
					uint64_t mask=0xFFFFFFFFFFFFFFFF; //mask used to only counts when pads had their first 1 in the FIFO
					for(int j=0;j<128;j++)			   //read each position in the FIFO
					{
						uint64_t pads=*(uint64_t*)(readarray+i+j*8); //get the 64 pads	
						pads=pads&mask; //exclude pads that already had 1s counted in a previous iteration
						bitset<64> bits(pads);
						int ones=0;
						for(int k=0;k<64;k++)
						{
							ones+=bits[k];
							avgbegbin3[k]+=bits[k]*j;
							totbegbin3[k]+=bits[k];
						}
						mask&=!pads; //turn to 0 all mask bits corresponding to pads that had 1s in this FIFO position
						total3+=ones;
						bins3[j]+=ones;	//increment the number of pads that started having 1s in this bin
					}
					i+=1024;
				}
				if(ports[3]) 
				{
					uint64_t mask=0xFFFFFFFFFFFFFFFF; //mask used to only counts when pads had their first 1 in the FIFO
					for(int j=0;j<128;j++)			   //read each position in the FIFO
					{
						uint64_t pads=*(uint64_t*)(readarray+i+j*8); //get the 64 pads	
						pads=pads&mask; //exclude pads that already had 1s counted in a previous iteration
						bitset<64> bits(pads);
						int ones=0;
						for(int k=0;k<64;k++)
						{
							ones+=bits[k];
							avgbegbin4[k]+=bits[k]*j;
							totbegbin4[k]+=bits[k];
						}
						mask&=!pads; //turn to 0 all mask bits corresponding to pads that had 1s in this FIFO position
						total4+=ones;
						bins4[j]+=ones;	//increment the number of pads that started having 1s in this bin
					}
				}
			}
		}
	}
	
	cout<<obt_numev<<" events were read in the files specified in the acquisition file"<<endl<<flush;

	cout<<"the average bin in which each MAROC channel started having 1s (when they did) in each port is:"<<endl<<flush;

	for(int i=0;i<64;i++)
	{
		if(ports[0])
		{
			float percent1=(float)(avgbegbin1[i])/(float)totbegbin1[i];
			cout<<"MAROC ch "<<i<<" port 1="<<percent1<<"%"<<"	";
		}
		if(ports[1])
		{
			float percent2=(float)(avgbegbin2[i])/(float)totbegbin2[i];
			cout<<"MAROC ch "<<i<<" port 2="<<percent2<<"%"<<"	";
		}
		if(ports[2])
		{
			float percent3=(float)(avgbegbin3[i])/(float)totbegbin3[i];
			cout<<"MAROC ch "<<i<<" port 3="<<percent3<<"%"<<"	";
		}
		if(ports[3])
		{
			float percent4=(float)(avgbegbin4[i])/(float)totbegbin4[i];
			cout<<"MAROC ch "<<i<<" port 4="<<percent4<<"%";
		}
		cout<<endl<<flush;
	}

	cout<<"the percentage of MAROC channels that began having 1s in each FIFO position, from the total of each respective interface port is:"<<endl<<flush;
	for(int i=0;i<128;i++)
	{
		if(ports[0])
		{
			float percent1=(float)(100*bins1[i])/(float)total1;
			cout<<"bin "<<i<<" port 1="<<percent1<<"%"<<"	";
		}
		if(ports[1])
		{
			float percent2=(float)(100*bins2[i])/(float)total2;
			cout<<"bin "<<i<<" port 2="<<percent2<<"%"<<"	";
		}
		if(ports[2])
		{
			float percent3=(float)(100*bins3[i])/(float)total3;
			cout<<"bin "<<i<<" port 3="<<percent3<<"%"<<"	";
		}
		if(ports[3])
		{
			float percent4=(float)(100*bins4[i])/(float)total4;
			cout<<"bin "<<i<<" port 4="<<percent4<<"%";
		}
		cout<<endl<<flush;
	}
	int beginbin1=0;
	int beginbin2=0;
	int beginbin3=0;
	int beginbin4=0;
	int size=0;
	while(true)
	{
		cout<<"type the desired window size (1 to 128):"<<endl<<flush; 
		cin >> size;
		cin.get();
		if(size<1||size>128)
		{
			cout<<"invalid input."<<endl<<flush; 
		}
		else
		{
			break;
		}
	}

	while(true&&ports[0])
	{
		cout<<"type in which bin you wish to begin the window at port 1 (from "<<0<<" to "<<(127-size+1)<<"):"<<endl<<flush; 
				cin >> beginbin1;
		cin.get();
		if(beginbin1<0||beginbin1>(127-size+1))
		{
			cout<<"invalid input."<<endl<<flush; 
		}
		else
		{
			break;
		}
	}
	while(true&&ports[1])
	{
			cout<<"type in which bin you wish to begin the window at port 2 (from "<<0<<" to "<<(127-size+1)<<"):"<<endl<<flush;
			cin >> beginbin2;
			cin.get();
			if(beginbin2<0||beginbin2>(127-size+1))
			{
					cout<<"invalid input."<<endl<<flush;
			}
			else
			{
					break;
			}
	}
	while(true&&ports[2])
	{
			cout<<"type in which bin you wish to begin the window at port 3 (from "<<0<<" to "<<(127-size+1)<<"):"<<endl<<flush;
			cin >> beginbin3;
			cin.get();
			if(beginbin3<0||beginbin3>(127-size+1))
			{
					cout<<"invalid input."<<endl<<flush;
			}
			else
			{
					break;
			}
	}
	while(true&&ports[3])
	{
			cout<<"type in which bin you wish to begin the window at port 4 (from "<<0<<" to "<<(127-size+1)<<"):"<<endl<<flush;
			cin >> beginbin4;
			cin.get();
			if(beginbin4<0||beginbin4>(127-size+1))
			{
					cout<<"invalid input."<<endl<<flush;
			}
			else
			{
					break;
			}
	}
	
	line="RH\t HOD_EVT_"+acq_date+".bin\t"+to_string(obt_numev)+"\t"+to_string(size)+"\t"+to_string(beginbin1)+"\t"+to_string(beginbin2)+"\t"+to_string(beginbin3)+"\t"+to_string(beginbin4)+"\n"; 
	auxfile.close();
	auxfile.clear();
	auxfile.open(acq_path, ios::app); //open aux text file 
	auxfile.write(line.data(),line.size());
	auxfile.close();
	ofstream reduced(reduced_path+"HOD_EVT_"+acq_date+".bin", std::ios::binary);
	reduced.write((char*)&selected,1);
	reduced.write((char*)&beginbin1,1);
	reduced.write((char*)&beginbin2,1);
	reduced.write((char*)&beginbin3,1);
	reduced.write((char*)&beginbin4,1);
	reduced.write((char*)&size,1);
	obt_numev=0;

	for (string name : bin_files)
	{
		ifstream bin((raw_path+name), std::ios::binary); //open raw binary file
		if(bin)
		{
			while(true)
			{
				bin.read((char*)readarray,nports*1024+18); //read event block
				if(bin.eof()) //tried to read after end of file
				{
					bin.close();
					bin.clear();
					break;
				}
				obt_numev++;
				if(obt_numev%1731==0) //print progress at every 1731 events
				{
					cout<<obt_numev<<"\r"<<flush;
				}
				int i=0;
				if(ports[0])  //if port is enabled
				{
					reduced.write((char*)(readarray+beginbin1*8),size*8);									
					i+=1024;
				}
				if(ports[1])  //if port is enabled
				{
					reduced.write((char*)(readarray+i+beginbin2*8),size*8);									
					i+=1024;
				}
				if(ports[2])  //if port is enabled
				{
					reduced.write((char*)(readarray+i+beginbin3*8),size*8);   
					i+=1024;								 
				}
				if(ports[3])  //if port is enabled
				{
					reduced.write((char*)(readarray+i+beginbin4*8),size*8);									
					i+=1024;
				}
				reduced.write((char*)(readarray+i),18);	
			}
		}
	}
	reduced.close();
	cout<<"finished."<<endl<<flush;
}
