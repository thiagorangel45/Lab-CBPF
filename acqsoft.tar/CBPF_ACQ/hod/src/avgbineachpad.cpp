#include <iomanip>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <cstdlib>
#include <iostream>
#include <math.h>
#include <unistd.h>
#include <fstream>
#include <bitset>
#include <vector>

using namespace std;


int main(int argc, char* argv[])
{   
	string acq_date(argv[1]);
	string raw_path="/data/DATA_"+acq_date+"/HOD_RAW/";
	string acq_path="/data/DATA_"+acq_date+"/ACQ.txt";
	string reduced_path="/data/DATA_"+acq_date+"/reduced_bins/";
	fstream auxfile(acq_path, ios_base::in); //open aux text file 
	vector  <string> bin_files;
	string line;
	getline(auxfile,line);  
	bitset<4> ports(line);			//converts the 4 bits from a string of chars to a bitset
	uint8_t selected=ports[0]+ports[1]*2+ports[2]*4+ports[3]*8;
	uint8_t nports=ports[0]+ports[1]+ports[2]+ports[3]; //number of enabled ports
	getline(auxfile,line);
	ulong req_numev=strtoul(line.c_str(),NULL,10);
	cout<<req_numev<<" events were required in the acquisiton"<<endl<<flush;
	cout<<"getting bin files list"<<endl<<flush;
	while(getline(auxfile,line))
	{
		vector  <string> tokens;
		istringstream iss(line);
		string token;
		getline(iss, token, '\t');
		if(strcmp(token.c_str(),"FO")==0)
		{
			getline(iss, token, '\t');
			bin_files.push_back(token);
			cout<<"appending file "<<token<<endl<<flush;
		}
	}
	ulong obt_numev;							 //create variable for obtained number of events
	uint8_t readarray[4114];				 //create array for reading FIFO blocks from file
	//create arrays for bin statistics of frontends in each interface port
	uint64_t avgbegbin1[64]={0};		
	uint64_t avgbegbin2[64]={0};		
	uint64_t avgbegbin3[64]={0};		
	uint64_t avgbegbin4[64]={0};	
	uint64_t totbegbin1[64]={0};		
	uint64_t totbegbin2[64]={0};
	uint64_t totbegbin3[64]={0};
	uint64_t totbegbin4[64]={0};
	

	for (string name : bin_files)
	{
		ifstream bin((raw_path+name), std::ios::binary); //open raw binary file
		if(bin)
		{
			while(true)
			{
				bin.read((char*)readarray,nports*1024+18); //read event block
				if(bin.eof()) //tried to read after end of file
				{
					bin.close();
					bin.clear();
					break;
				}
				obt_numev++;
				if(obt_numev%1731==0) //print progress at every 1731 events
				{
					cout<<obt_numev<<"\r"<<flush;
				}
				int i=0;
				if(ports[0])  //if port is enabled
				{
					uint64_t mask=0xFFFFFFFFFFFFFFFF; //mask used to only counts when pads had their first 1 in the FIFO
					for(int j=0;j<128;j++)			   //read each position in the FIFO
					{
						uint64_t pads=*(uint64_t*)(readarray+j*8); //get the 64 pads	
						pads=pads&mask; //exclude pads that already had 1s counted in a previous FIFO position
						bitset<64> bits(pads);
						int ones=0;
						for(int k=0;k<64;k++)
						{
							if(bits[k])
							{
								avgbegbin1[k]+=j;
								totbegbin1[k]++;
							}
						}
						mask&=~pads; //turn to 0 all mask bits corresponding to pads that had 1s in this FIFO position for the first time
					}
					i+=1024;
				}
				if(ports[1]) 
				{
					uint64_t mask=0xFFFFFFFFFFFFFFFF; //mask used to only counts when pads had their first 1 in the FIFO
					for(int j=0;j<128;j++)			   //read each position in the FIFO
					{
						uint64_t pads=*(uint64_t*)(readarray+i+j*8); //get the 64 pads	
						pads=pads&mask; //exclude pads that already had 1s counted in a previous iteration
						bitset<64> bits(pads);
						int ones=0;
						for(int k=0;k<64;k++)
						{
							if(bits[k])
							{
								avgbegbin2[k]+=j;
								totbegbin2[k]++;
							}
						}
						mask&=~pads; //turn to 0 all mask bits corresponding to pads that had 1s in this FIFO position for the first time
					}
					i+=1024;
				}
				if(ports[2]) 
				{
					uint64_t mask=0xFFFFFFFFFFFFFFFF; //mask used to only counts when pads had their first 1 in the FIFO
					for(int j=0;j<128;j++)			   //read each position in the FIFO
					{
						uint64_t pads=*(uint64_t*)(readarray+i+j*8); //get the 64 pads	
						pads=pads&mask; //exclude pads that already had 1s counted in a previous iteration
						bitset<64> bits(pads);
						int ones=0;
						for(int k=0;k<64;k++)
						{
							if(bits[k])
							{
								avgbegbin3[k]+=j;
								totbegbin3[k]++;
							}
						}
						mask&=~pads; //turn to 0 all mask bits corresponding to pads that had 1s in this FIFO position for the first time
					}
					i+=1024;
				}
				if(ports[3]) 
				{
					uint64_t mask=0xFFFFFFFFFFFFFFFF; //mask used to only counts when pads had their first 1 in the FIFO
					for(int j=0;j<128;j++)			   //read each position in the FIFO
					{
						uint64_t pads=*(uint64_t*)(readarray+i+j*8); //get the 64 pads	
						pads=pads&mask; //exclude pads that already had 1s counted in a previous iteration
						bitset<64> bits(pads);
						int ones=0;
						for(int k=0;k<64;k++)
						{
							if(bits[k])
							{
								avgbegbin4[k]+=j;
								totbegbin4[k]++;
							}
						}
						mask&=~pads; //turn to 0 all mask bits corresponding to pads that had 1s in this FIFO position for the first time
					}
				}
			}
		}
	}
	
	cout<<obt_numev<<" events were read in the files specified in the acquisition file"<<endl<<flush;

	cout<<"the average bin in which each MAROC channel started having 1s (when they did) in each port is:"<<endl<<flush;

	for(int i=0;i<64;i++)
	{
		if(ports[0])
		{
			float percent1=(float)(avgbegbin1[i])/(float)totbegbin1[i];
			cout<<"MAROC ch "<<i<<" port 1="<<percent1<<"	";
		}
		if(ports[1])
		{
			float percent2=(float)(avgbegbin2[i])/(float)totbegbin2[i];
			cout<<"MAROC ch "<<i<<" port 2="<<percent2<<"	";
		}
		if(ports[2])
		{
			float percent3=(float)(avgbegbin3[i])/(float)totbegbin3[i];
			cout<<"MAROC ch "<<i<<" port 3="<<percent3<<"	";
		}
		if(ports[3])
		{
			float percent4=(float)(avgbegbin4[i])/(float)totbegbin4[i];
			cout<<"MAROC ch "<<i<<" port 4="<<percent4;
		}
		cout<<endl<<flush;
	}
}
