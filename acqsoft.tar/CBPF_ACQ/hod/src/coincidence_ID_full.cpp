#include "config.cpp" //cointains configuration software, which in turn contains the LVDS communication and memory manager
#include <chrono>
#include <ctime>
#include <time.h>
#include <string.h>

using namespace std;

string zeropad(int number)
{
	if(number<10)
	{
		return "0"+to_string(number);	
	}
	else 
	{
		return to_string(number);	
	}
}

string make_evt_name()
{
	struct tm *timestamp;				
	time_t currdate;								 
	time(&currdate);
	timestamp = localtime(&currdate); 
	string second=zeropad(timestamp->tm_sec);
	string minute=zeropad(timestamp->tm_min);
	string hour=zeropad(timestamp->tm_hour);
	string day=zeropad(timestamp->tm_mday);
	string month=zeropad(1+timestamp->tm_mon);
	string year=to_string(1900+timestamp->tm_year);
	string name="HOD_"+year+"_"+month+"_"+day+"_"+hour+minute+second+".bin";
	return name;
}

string make_rate_name()
{
	struct tm *timestamp;				
	time_t currdate;								 
	time(&currdate);
	timestamp = localtime(&currdate); 
	string second=zeropad(timestamp->tm_sec);
	string minute=zeropad(timestamp->tm_min);
	string hour=zeropad(timestamp->tm_hour);
	string day=zeropad(timestamp->tm_mday);
	string month=zeropad(1+timestamp->tm_mon);
	string year=to_string(1900+timestamp->tm_year);
	string name="RATE_"+year+"_"+month+"_"+day+"_"+hour+minute+second+".bin";
	return name;
}

void new_evt_file(ofstream& binary, ofstream& aux,string dirname, string name, unsigned long ev_count, unsigned long trigger_count, uint16_t lts_id, uint32_t overflow_counter, uint64_t time)
{
	binary.open(("/data/"+dirname+"/HOD_RAW/"+name), std::ios::binary);	
	string line="FO\t"+name+"\t"+to_string(ev_count)+"\t"+to_string(trigger_count)+"\t"+to_string(lts_id)+"\t"+to_string(overflow_counter)+"\t"+to_string(time)+"\n";
	//cout<<line<<flush;
	aux.write(line.data(),line.size());
	aux.flush();
}

void new_rate_file(ofstream& binary, ofstream& aux,string dirname, string name)
{
	binary.open(("/data/"+dirname+"/HOD_RAW/"+name), std::ios::binary);	
	string line="RT\t"+name+"\n";
	//cout<<line<<flush;
	aux.write(line.data(),line.size());
	aux.flush();
}

void close_file(ofstream& binary, ofstream& aux,string name, unsigned long ev_count, unsigned long trigger_count, uint16_t lts_id, uint32_t overflow_counter,uint64_t time)
{
	binary.close();
	binary.clear();
	string line="FC\t"+name+"\t"+to_string(ev_count)+"\t"+to_string(trigger_count)+"\t"+to_string(lts_id)+"\t"+to_string(overflow_counter)+"\t"+to_string(time)+"\n";
	//cout<<line<<flush;
	aux.write(line.data(),line.size());
	aux.flush();
}

void overflow(ofstream& aux, uint32_t overflow_counter, unsigned long ev_count, unsigned long trigger_count, uint16_t oldid, uint16_t newid)
{
	struct tm *timestamp;				
	time_t currdate;								 
	time(&currdate);
	timestamp = localtime(&currdate); 
	string second=zeropad(timestamp->tm_sec);
	string minute=zeropad(timestamp->tm_min);
	string hour=zeropad(timestamp->tm_hour);
	string day=zeropad(timestamp->tm_mday);
	string month=zeropad(1+timestamp->tm_mon);
	string year=to_string(1900+timestamp->tm_year);
	string line="OF\t"+to_string(overflow_counter)+"\t"+year+"\t"+month+"\t"+day+"\t"+hour+"\t"+minute+"\t"+second+"\t"+to_string(ev_count)+"\t"+to_string(trigger_count)+"\t"+to_string(oldid)+"\t"+to_string(newid)+"\n";
	//cout<<line<<flush;
	aux.write(line.data(),line.size());
	aux.flush();
}

int dumpfifos(uint8_t* readarray, uint8_t* verify, bitset<4>channels)
{
	int fail=0;
	while((verify[0]!=231&&channels[0])||(verify[1]!=231&&channels[1])||(verify[2]!=231&&channels[2])||(verify[3]!=231&&channels[3])) //read until dumping all FIFOS
	{
		read_to_array(readarray,32,1024,channels); //dump any remaining FIFOS
		int out=1;
		while(out!=0 && fail<20)
		{
			out=fixed_read_to_array(verify,31,1,channels); //read the status of the FIFOS until obtain success
			fail++;
		}
		if(fail>=20){return 1;}
	}
	return 0;
}

int getfifostat(uint8_t* verify, bitset<4>channels)
{
	int fail=0;
	while(true)
	{
		int out=1;
		while(out!=0 && fail<20)
		{
			out=fixed_read_to_array(verify,31,1,channels); //read the status of the FIFOS until obtain success
			fail++;
		}	
		if(fail>=20){return 1;}
		if((verify[0]==24||verify[0]==231||!channels[0])&&(verify[1]==24||verify[1]==231||!channels[1])&&(verify[2]==24||verify[2]==231||!channels[2])&&(verify[3]==24||verify[3]==231||!channels[3]))
		{
			return 0;
		}
	}
}

int insist_read(uint8_t* array, uint8_t address, uint16_t nbytes,bitset<4>channels)
{
	int fail=0;
	int out=1;
	while(out!=0 && fail<10)
	{
		out=read_to_array(array,address,nbytes,channels); //read the status of the FIFOS until obtain success
		fail++;
	}	
	if(fail>=10){return 1;}
	return 0;
}

int insist_fixed_read(uint8_t* array, uint8_t address, uint16_t nbytes,bitset<4>channels)
{
	int fail=0;
	int out=1;
	while(out!=0 && fail<10)
	{
		out=fixed_read_to_array(array,address,nbytes,channels); //read the status of the FIFOS until obtain success
		fail++;
	}	
	if(fail>=10){return 1;}
	return 0;
}

int insist_write(uint8_t* array, uint8_t address, uint16_t nbytes,bitset<4>channels)
{
	int fail=0;
	int out=1;
	while(out!=0 && fail<10)
	{
		out=write_from_array(array,address,nbytes,channels); //read the status of the FIFOS until obtain success
		fail++;
	}	
	if(fail>=10){return 1;}
	return 0;
}


int main(int argc, char* argv[])
{
	if(argc==8)
	{		
		//array declarations that don't depend on pointers nor any other previous variable

		uint8_t frontend_trig_num[1]={0};	 //variable with the trig number to be set on the frontend (0 for using central unit trigger)
		uint8_t sttm_on[1]={0x0F};			 //variable to start frontend state machines
		uint8_t sttm_off[1]={0xF0};			 //variable to stop frontend state machines
		uint8_t verify[4];				//array to save fixed-position 1-byte data read from frontends
		uint8_t readarray[4096]={0};		 //array to save FIFOS (1024 bytes each) from frontends
		uint32_t overflow_counter=0;
		string evt_file_name;
		string rate_file_name;
		//order dependent part

		map_memory();						//maps process space memory to physical memory and enable using the pointers inherited from lvds-memory-manager
		string chs(argv[1]);				//string with enabled interface channels specification (4 bits written with chars, LSB is interface channel 1).
		bitset<4> channels(chs);			//converts the 4 bits from a string of chars to a bitset
		uint8_t nchannels=channels[0]+channels[1]+channels[2]+channels[3]; //number of enabled channels
		uint16_t logic=strtoul(argv[2],NULL,16);	//convert trigger logic hex input into 16 bit integer
		uint8_t mode=strtoul(argv[3],NULL,16);		//convert trigger logic hex input into 16 bit integer
		*trigger_logic_bits=logic;			//sets the central unit trigger logic
		*trigger_mode=mode;					//sets the central unit trigger mode 
		*trigger_enable=0;					//disables central unit trigger output
		ulong trigger_count=0;	//creates trigger counter (store total amount of triggers, independently of success in saving events)
		ulong lts_err=0;
		ulong ftend_err=0;		
		uint16_t oldID=0;
		ulong numev=strtoul(argv[4],NULL,10);			//convert number of events into unsigned long
		ofstream outfile;
		ofstream ratefile;
		int latency= strtoul(argv[5],NULL,10);
		bool havelts=(bool)strtoul(argv[6],NULL,10);
		string dirname(argv[7]);
		ofstream auxfile(("/data/"+dirname+"/ACQ.txt"), ios_base::out);
		string selected(argv[1]);
		string number_ev(argv[4]);
		selected+="\n";
		number_ev+="\n";
		auxfile.write(selected.data(),selected.size());	//save the selected channels in aux file 
		auxfile.write(number_ev.data(),number_ev.size());	//save the number of requested events in aux file
		bool closed=1;
		rate_file_name=make_rate_name();
		new_rate_file(ratefile,auxfile,dirname,rate_file_name);
		int fail;
	
		//The hit FSM must be started to ensure the FIFOs can be emptied

		fail=insist_write(frontend_trig_num,90,1,channels);			//set the frontends in selected channels to the specified trigger number (0)
		if(fail){cout<<"Address 90 (set ftend trigger) write failed"<<endl<<flush;return 1;}
		fail=insist_write(sttm_on,33,1,channels);						//start the hit state machine in the frontends in the enabled channels 
		if(fail){cout<<"Address 33 (start hit stt machine) write failed "<<endl<<flush;return 1;}

		//make sure all FIFOS are empty in all front-ends

		fail=getfifostat(verify,channels);
		if(fail){cout<<"failed getting fifo stat\n"<<(int)verify[0]<<"\t"<<(int)verify[1]<<"\t"<<(int)verify[2]<<"\t"<<(int)verify[3]<<"\t"<<flush;return 1;}	
		fail=dumpfifos(readarray,verify,channels);  
		if(fail){cout<<"failed dumping fifos"<<flush;return 1;}	  
		fail=insist_write(sttm_off,33,1,channels);	  //stop the state machine so it wont get the triggers while booting up the lts_id reading mechanism
		if(fail){cout<<"Address 33 (stop hit stt machine) write failed "<<endl<<flush;return 1;}



		int success_count=0;

		//boot up lts_id reading mechanism if lts is being used

		while(success_count<3 && havelts) //loop taking lts_IDs until there's a sequence of 3 consecutive valid IDs
		{
			cout<<*lts_id<<endl<<flush;
			*trigger_enable=1;	  //enables central unit trigger
			usleep(100);
			if(*trigger_read!=0)
			{
				*trigger_enable=0;	//enables central unit trigger
				if((((oldID>(uint16_t)*lts_id)&&(oldID>65335)&&((uint16_t)*lts_id<200))||(((uint16_t)*lts_id>oldID)&&((uint16_t)*lts_id<(oldID+200))))) //checks if the new ID is coherent with the last successfully received ID
				{
					oldID=*lts_id;
					success_count++;
				}
				else //if it isn't, try again with the next ID	
				{
					oldID=*lts_id;
					success_count=0;
				}		

			}
		}	

		//start hit FSMs on frontends
		fail=insist_write(sttm_on,33,1,channels);						//start the hit state machine in the frontends in the enabled channels 
		if(fail){cout<<"Address 33 (start hit stt machine) write failed "<<endl<<flush;return 1;}
		int out;
		struct tm *timestamp;				//creates structure for timestamp 
		time_t currdate;								 
		time(&currdate);
		timestamp = localtime(&currdate);	//saves local date and time to timestamp variables
		uint8_t tsarray[6]={timestamp->tm_hour,timestamp->tm_min,timestamp->tm_sec,timestamp->tm_mday,timestamp->tm_mon,timestamp->tm_year}; //creates array with start timestamp variables for this file
		uint64_t last_time_ms=-latency*60000+chrono::duration_cast<chrono::milliseconds>(chrono::system_clock::now().time_since_epoch()).count();
		*trigger_enable=1;
		for(ulong i=0;i<numev;)
		{
			if(*trigger_read!=0)	//check trigger variable to see if it's different from zero
			{
				uint64_t time_ms = chrono::duration_cast<chrono::milliseconds>(chrono::system_clock::now().time_since_epoch()).count();


				if(time_ms-last_time_ms>=latency*60000)
				{
					last_time_ms=time_ms;
					fail=insist_read(readarray,75,128,channels);
					if(fail){cout<<"failed reading rates"<<flush;return 1;} 
					ratefile.write((char*)&time_ms,8);	
					ratefile.write((char*)&readarray,128*nchannels);
				}
				trigger_count++;
				fail=getfifostat(verify,channels);
				if(fail){cout<<"failed getting fifo stat"<<flush;;return 1;} 
				if((verify[0]==24||!channels[0])&&(verify[1]==24||!channels[1])&&(verify[2]==24||!channels[2])&&(verify[3]==24||!channels[3])) 
				{
					out=read_to_array(readarray,32,1024,channels);	//if there was a trigger, read the fifos from the frontends on selected channels to the central unit memory and save them on the file
					if(out!=0) //if all were ready but there was a failure reading, read the status of the frontends in each channel again
					{
						fail=getfifostat(verify,channels);
						if(fail){cout<<"failed getting fifo stat"<<flush;return 1;} 
						out=1; //send it back to 1 to inform the next conditional there was an error
					}
				}
				else 
				{
					out=1; //not all were ready
				}
				if(out!=0)	//either some wasn't ready or all were ready but there was a read error			
				{	
					dumpfifos(readarray,verify,channels); //dump any remaining fifos
					if(havelts)
					{
						usleep(5); //ensure LTS_ID came, once that, in case of error, the system might be too fast for not reading the FIFOS
					}
					ftend_err++;
					//cout<<"E_ftend"<<endl<<flush;
					if(havelts)
					{
						if((((oldID>(uint16_t)*lts_id)&&(oldID>65335)&&((uint16_t)*lts_id<200))||(((uint16_t)*lts_id>oldID)&&((uint16_t)*lts_id<(oldID+200)))))
						{
							if(oldID>(uint16_t)*lts_id)
							{
								overflow_counter++;
								overflow(auxfile,overflow_counter,i,trigger_count,oldID,*lts_id);			 
							}
							oldID=*lts_id;
						}
						else
						{
							lts_err++;
							//cout<<"E_lts"<<endl<<flush;
						}	
					}
					*trigger_enable=0; //resets trigger
					*trigger_enable=1;
				}
				else
				{
					if(!havelts||((((oldID>(uint16_t)*lts_id)&&(oldID>65335)&&((uint16_t)*lts_id<200))||(((uint16_t)*lts_id>oldID)&&((uint16_t)*lts_id<(oldID+200))))))//checks if LTS_ID was properly read
					{
						if(havelts && oldID>(uint16_t)*lts_id) 
						{
							overflow_counter++;
							overflow(auxfile,overflow_counter,i,trigger_count,oldID,*lts_id);									
						} 
						if(closed)
						{
							evt_file_name=make_evt_name();
							new_evt_file(outfile,auxfile,dirname,evt_file_name,i,trigger_count-1,*lts_id,overflow_counter,time_ms);
							closed=0;
						}
						oldID=*lts_id*havelts;
						outfile.write((char*)readarray,1024*nchannels); 
						outfile.write((char*)&time_ms,8);
						outfile.write((char*)&trigger_count,4); 
						outfile.write((char*)&oldID,2);
						outfile.write((char*)&overflow_counter,4); 
						outfile.flush();
						*trigger_enable=0; //resets trigger
						i++;					//if there was no error, increment event counter and print the event number if it reached a multiple of 100
						if((i%1000)==0)
						{
							cout<<i<<endl<<flush;
						}
						if((i%50000)==0 || i==numev)
						{
							close_file(outfile,auxfile,evt_file_name,(i-1),trigger_count-1,*lts_id,overflow_counter,time_ms);
							closed=1;
						}
						if(i<numev)
						{
							*trigger_enable=1;
						}
					}
					else
					{
						lts_err++;
						//cout<<oldID<<" "<<(int)*lts_id<<" E_lts"<<endl<<flush;
						*trigger_enable=0;
						*trigger_enable=1;
					}
				}
			}
		}
		time(&currdate);
		timestamp = localtime(&currdate);	//saves local date and time to timestamp variables
		cout<<numev<<endl<<flush;
		uint8_t tearray[6]={timestamp->tm_hour,timestamp->tm_min,timestamp->tm_sec,timestamp->tm_mday,timestamp->tm_mon,timestamp->tm_year}; //creates array with start timestamp variables for this file 
		cout<<"total number of triggers (including those with subsequent read failures): "<<trigger_count<<endl<<flush; 
		cout<<"aquisition began at "<<(int)tsarray[0]<<":"<<(int)tsarray[1]<<":"<<(int)tsarray[2]<<"	"<<(int)tsarray[3]<<"/"<<(int)tsarray[4]+1<<"/"<<(int)tsarray[5]+1900<<endl<<flush;
		cout<<"aquisition ended at "<<(int)tearray[0]<<":"<<(int)tearray[1]<<":"<<(int)tearray[2]<<"	"<<(int)tearray[3]<<"/"<<(int)tearray[4]+1<<"/"<<(int)tearray[5]+1900<<endl<<flush;
		fail=insist_write(sttm_off,33,1,channels);						//start the hit state machine in the frontends in the enabled channels 
		if(fail){cout<<"Address 33 (stop hit stt machine) write failed "<<endl<<flush;return 1;}		
		unmap_memory();			//unmaps memory
		return 0;				//returns 0 (everything was successful) 
	}
	else
	{
		cout<<"This program must receive exactly 7 arguments (enabled interface channels, trigger logic, trigger mode, number of events, rate measurement interval (in minutes), lts usage (0=ignore lts, 1=use lts), output directory name (which should be in /data/)"<<endl<<flush;
		return 1;
	}
}
