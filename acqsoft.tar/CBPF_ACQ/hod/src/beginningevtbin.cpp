#include <iomanip>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <cstdlib>
#include <iostream>
#include <math.h>
#include <unistd.h>
#include <fstream>
#include <bitset>
#include <vector>

using namespace std;


int main(int argc, char* argv[])
{   
	string acq_date(argv[1]);
	int tolerance=strtoul(argv[2],NULL,10);	
	string raw_path="/data/DATA_"+acq_date+"/HOD_RAW/";
	string acq_path="/data/DATA_"+acq_date+"/ACQ.txt";
	string reduced_path="/data/DATA_"+acq_date+"/reduced_bins/";
	fstream auxfile(acq_path, ios_base::in); //open aux text file 
	vector  <string> bin_files;
	string line;
	getline(auxfile,line);  
	bitset<4> ports(line);			//converts the 4 bits from a string of chars to a bitset
	uint8_t selected=ports[0]+ports[1]*2+ports[2]*4+ports[3]*8;
	uint8_t nports=ports[0]+ports[1]+ports[2]+ports[3]; //number of enabled ports
	getline(auxfile,line);
	ulong req_numev=strtoul(line.c_str(),NULL,10);
	cout<<req_numev<<" events were required in the acquisiton"<<endl<<flush;
	getline(auxfile,line);
	getline(auxfile,line);
	getline(auxfile,line);
	getline(auxfile,line);
	cout<<"getting bin files list"<<endl<<flush;
	while(getline(auxfile,line))
	{
		vector  <string> tokens;
		istringstream iss(line);
		string token;
		getline(iss, token, '\t');
		if(strcmp(token.c_str(),"FO")==0)
		{
			getline(iss, token, '\t');
			bin_files.push_back(token);
			cout<<"appending file "<<token<<endl<<flush;
		}
	}
	ulong obt_numev;							 //create variable for obtained number of events
	uint8_t readarray[4114];				 //create array for reading FIFO blocks from file
	//create arrays for bin statistics of frontends in each interface port
	uint64_t bins[128]={0};	
	uint64_t totalvalid=0;	

	for (string name : bin_files)
	{
		ifstream bin((raw_path+name), std::ios::binary); //open raw binary file
		if(bin)
		{
			while(true)
			{
				bin.read((char*)readarray,nports*1024+18); //read event block
				if(bin.eof()) //tried to read after end of file
				{
					bin.close();
					bin.clear();
					break;
				}
				obt_numev++;
				if(obt_numev%1731==0) //print progress at every 1731 events
				{
					cout<<obt_numev<<"\r"<<flush;
				}
				int i=0;
				int begin1=1;	
				int begin2=1;
				int begin3=1;
				int begin4=1;	
				if(ports[0])  //if port is enabled
				{
					uint64_t last=*(uint64_t*)(readarray);
					for(int j=1;j<128;j++)			   //read each position in the FIFO
					{
						uint64_t pads=*(uint64_t*)(readarray+j*8); //get the 64 pads	
						uint64_t newbits=(pads^last)&(~last); //verify it any bit flipped from 0 to 1 since the last iteration
						if(newbits){break;} //if any bit flipped in this fifo position
						begin1++;
					}
					i+=1024;
				}
				if(ports[1]) 
				{
                                        uint64_t last=*(uint64_t*)(readarray+i); 
                                        for(int j=1;j<128;j++)                     //read each position in the FIFO
                                        {
                                                uint64_t pads=*(uint64_t*)(readarray+i+j*8); //get the 64 pads
                                                uint64_t newbits=(pads^last)&(~last); //verify it any bit flipped from 0 to 1 since the	last iteration
                                                if(newbits){break;} //if any bit flipped in this fifo position 
                                                begin2++;
                                        }
					i+=1024;
				}
				if(ports[2]) 
				{
					uint64_t last=*(uint64_t*)(readarray+i);
                                        for(int j=1;j<128;j++)                     //read each position in the FIFO
                                        {
                                                uint64_t pads=*(uint64_t*)(readarray+i+j*8); //get the 64 pads
                                                uint64_t newbits=(pads^last)&(~last); //verify it any bit flipped from 0 to 1 since the last iteration
                                                if(newbits){break;} //if any bit flipped in this fifo position
                                                begin3++;
                                        }
					i+=1024;
				}
				if(ports[3]) 
				{
			                uint64_t last=*(uint64_t*)(readarray+i);
                                        for(int j=1;j<128;j++)                     //read each position in the FIFO
                                        {
                                                uint64_t pads=*(uint64_t*)(readarray+i+j*8); //get the 64 pads
                                                uint64_t newbits=(pads^last)&(~last); //verify it any bit flipped from 0 to 1 since the last iteration
                                                if(newbits){break;} //if any bit flipped in this fifo position
                                                begin4++;
                                        }			
				}
				int first=128;
				int last=0;
				if(first>begin1 && ports[0]){first=begin1;}
				if(first>begin2 && ports[1]){first=begin2;}
				if(first>begin3 && ports[2]){first=begin3;}
				if(first>begin4 && ports[3]){first=begin4;}
				if(last<begin1<128  && ports[0]){last=begin1;}
				if(last<begin2<128  && ports[1]){last=begin2;}
				if(last<begin3<128  && ports[2]){last=begin3;}
				if(last<begin4<128  && ports[3]){last=begin4;}
				//cout<<first<<"	"<<last<<"	"<<tolerance<<endl<<flush;
				if(0<=(last-first) && (last-first)<=tolerance && first<128)
				{	
					totalvalid++;
					bins[first]++;
				}
			}
		}
	}
	
	cout<<obt_numev<<" events were read in the files specified in the acquisition file, of which "<<totalvalid<<" were considered valid given the tolerance"<<endl<<flush;


	cout<<"the percentage of valid events that began having in each FIFO position is:"<<endl<<flush;
	for(int i=0;i<128;i++)
	{
		float percent=(float)(100*bins[i])/(float)totalvalid;
		cout<<"bin "<<i<<"="<<percent<<"%"<<endl<<flush;
	}
	int beginbin=0;
	int size=0;
	while(true)
	{
		cout<<"type the desired window size (1 to 128):"<<endl<<flush; 
		cin >> size;
		cin.get();
		if(size<1||size>128)
		{
			cout<<"invalid input."<<endl<<flush; 
		}
		else
		{
			break;
		}
	}

	while(true)
	{
		cout<<"type in which bin you wish to begin the window, from "<<0<<" to "<<(127-size+1)<<"):"<<endl<<flush; 
		cin >> beginbin;
		cin.get();
		if(beginbin<0||beginbin>(127-size+1))
		{
			cout<<"invalid input."<<endl<<flush; 
		}
		else
		{
			break;
		}
	}
	
	line="RH\t HOD_EVT_"+acq_date+".bin\t"+to_string(obt_numev)+"\t"+to_string(size)+"\t"+to_string(beginbin)+"\t"+to_string(beginbin)+"\t"+to_string(beginbin)+"\t"+to_string(beginbin)+"\n"; 
	auxfile.close();
	auxfile.clear();
	auxfile.open(acq_path, ios::app); //open aux text file 
	auxfile.write(line.data(),line.size());
	auxfile.close();
	ofstream reduced(reduced_path+"HOD_EVT_"+acq_date+".bin", std::ios::binary);
	reduced.write((char*)&selected,1);
	reduced.write((char*)&beginbin,1);
	reduced.write((char*)&beginbin,1);
	reduced.write((char*)&beginbin,1);
	reduced.write((char*)&beginbin,1);
	reduced.write((char*)&size,1);
	obt_numev=0;

	for (string name : bin_files)
	{
		ifstream bin((raw_path+name), std::ios::binary); //open raw binary file
		if(bin)
		{
			while(true)
			{
				bin.read((char*)readarray,nports*1024+18); //read event block
				if(bin.eof()) //tried to read after end of file
				{
					bin.close();
					bin.clear();
					break;
				}
				obt_numev++;
				if(obt_numev%1731==0) //print progress at every 1731 events
				{
					cout<<obt_numev<<"\r"<<flush;
				}
				int i=0;
				if(ports[0])  //if port is enabled
				{
					uint64_t stuck=0;
					for(int j=0;j<128;j++)
					{
						stuck&=*(uint64_t*)(readarray+i+j*8);
					}
					reduced.write((char*)(&stuck),8);
					reduced.write((char*)(readarray+i+beginbin*8),size*8);								
					i+=1024;
				}
				if(ports[1])  //if port is enabled
				{
                                        uint64_t stuck=0;
                                        for(int j=0;j<128;j++)
                                        {
                                                stuck&=*(uint64_t*)(readarray+i+j*8);
                                        }
                                        reduced.write((char*)(&stuck),8);
					reduced.write((char*)(readarray+i+beginbin*8),size*8);									
					i+=1024;
				}
				if(ports[2])  //if port is enabled
				{
                                        uint64_t stuck=0;
                                        for(int j=0;j<128;j++)
                                        {
                                                stuck&=*(uint64_t*)(readarray+i+j*8);
                                        }
                                        reduced.write((char*)(&stuck),8);
					reduced.write((char*)(readarray+i+beginbin*8),size*8);   
					i+=1024;								 
				}
				if(ports[3])  //if port is enabled
				{
                                        uint64_t stuck=0;
                                        for(int j=0;j<128;j++)
                                        {
                                                stuck&=*(uint64_t*)(readarray+i+j*8);
                                        }
                                        reduced.write((char*)(&stuck),8);
					reduced.write((char*)(readarray+i+beginbin*8),size*8);									
					i+=1024;
				}
				reduced.write((char*)(readarray+i),18);	
			}
		}
	}
	reduced.close();
	cout<<"finished."<<endl<<flush;
}
