#include "config.cpp"
#include <chrono>

int main(int argc, char* argv[])
{
        if(argc==2)
        {		
                map_memory();
		string rpc(argv[1]);
                bitset<4> rpcs(rpc);
		uint64_t mask;
		read_to_array((uint8_t*)&mask,76,8,rpcs);
		bitset<64> maskbit(mask);
		for(int i=0 ; i<64 ; i++)
		{
			cout<<maskbit[i]<<endl<<flush;
		}
                unmap_memory();
                return 0;
        }
	else
	{
                cout<<"esse script deve receber exatamente 1 argumento (rpcs selecionadas)"<<endl<<flush;
        }
}









