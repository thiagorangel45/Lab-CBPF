#include "config.cpp" //cointains configuration software, which in turn contains the LVDS communication and memory manager
#include <chrono>
#include <ctime>
#include <time.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/unistd.h>


using namespace std;

int main(int argc, char* argv[])
{
	if(argc==4)
	{		
		map_memory();						//maps process space memory to physical memory and enable using the pointers inherited from lvds-memory-manager
		uint16_t logic=strtoul(argv[1],NULL,16);	//convert trigger logic hex input into 16 bit integer
		uint8_t mode=strtoul(argv[2],NULL,16);		//convert trigger logic hex input into 16 bit integer
		*trigger_logic_bits=logic;			//sets the central unit trigger logic
		*trigger_mode=mode;					//sets the central unit trigger mode 
		*trigger_enable=0;					//disables central unit trigger output
		ulong noftrig=strtoul(argv[3],NULL,10);			//get the RATE reading duration (in minutes)		
		ulong trigger_count=0;	//creates trigger counter (store total amount of triggers sent to the front-ends, independently of success in saving events)   	
		uint64_t last_time_ms=chrono::duration_cast<chrono::milliseconds>(chrono::system_clock::now().time_since_epoch()).count();
		*trigger_enable=1;
		while(true) 
		{
			if(*trigger_read!=0)	//check trigger variable to see if it's different from zero, in which case the Central Unit already sent the trigger response back to the front-ends
			{
				trigger_count++; //increment trigger variable
				if(trigger_count<noftrig)
				{
                			*trigger_enable=0;
		                	*trigger_enable=1;
				}
				else 
				{
					break;
				}
			}
		}
		uint64_t time_ms=chrono::duration_cast<chrono::milliseconds>(chrono::system_clock::now().time_since_epoch()).count();	
		float duration=(float)(time_ms-last_time_ms)/1000.0; 
		cout<<((float)trigger_count/duration)<<endl<<flush;
	    	unmap_memory();			//unmaps memory
		return 0;				//returns 0 (everything was successful) 
	}
	else
	{
		cout<<"This program must receive exactly 3 arguments (trigger logic, trigger mode, number of triggers to measure"<<endl<<flush;
		return 1;
	}
}
