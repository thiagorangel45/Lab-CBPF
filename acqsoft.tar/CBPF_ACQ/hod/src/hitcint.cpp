#include "config.cpp" //cointains configuration software, which in turn contains the LVDS communication and memory manager
#include <chrono>
#include <ctime>
#include <time.h>


int main(int argc, char* argv[])
{
	if(argc==3)
	{		
		map_memory();							   //maps process space memory to physical memory
		*trigger_enable=0x00;					   //disables central unit trigger output
		char *ptr=NULL;							    //NULL pointer required by strtoul
		ulong numev=strtoul(argv[2],&ptr,10);	    //convert number of events into unsigned long
		string chs(argv[1]);				 //string with enabled interface channels specification (4 bits written with chars, LSB is interface channel 1).
		bitset<4> channels(chs);			 //converts the 4 bits from a string of chars to a bitset
		uint8_t frontend_trig_num[1]={0x0};	 //variable with the trig number to be set on the frontend (0 for using central unit trigger)
		uint8_t sttm_on[1]={0x0F};			 //variable to start frontend state machines
		uint8_t sttm_off[1]={0xF0};			 //variable to stop frontend state machines
		uint8_t zeros[4096]={0};			 //array with zeros to write in case of frontend read error, to maintain 1:1 relationship between blocks and triggers
		int out=write_from_array(frontend_trig_num,90,1,channels);			//set the frontends in selected channels to the specified trigger number (0)
		cout<<"Address 90 (set ftend trigger) status: "<<out<<endl<<flush;	//prints the write status (should be 0)
		out=write_from_array(sttm_on,33,1,channels);					   //start the hit state machine in the frontends in the enabled channels
		cout<<"Address 33 (start hit stt machine) status: "<<out<<endl<<flush; 
		*trigger_mode=0xC0;		        //sets the central unit trigger mode  
		uint8_t selected=(uint8_t)(channels.to_ulong());
		struct tm *timestamp;				//creates structure for timestamp 
		time_t currdate;								 
		time(&currdate);
		uint8_t result[1];
		int padcounter[64]={0};
		timestamp = localtime(&currdate);	//saves local date and time to timestamp variables
		uint8_t tsarray[6]={timestamp->tm_hour,timestamp->tm_min,timestamp->tm_sec,timestamp->tm_mday,timestamp->tm_mon,timestamp->tm_year}; //creates array with start timestamp variables
	  	auto start = chrono::high_resolution_clock::now(); //get current microssecond clock value for starting time  
		*trigger_enable=0x01;							   //enables central unit trigger
		uint8_t FIFOarray[1024];
		for(ulong i=0;i<numev;)
		{
			read_to_array(result,31,1,channels);
			if(result[0]==24)  //check if there was trigger
			{
				int out=read_to_array(FIFOarray,32,1024,channels); //if there was a trigger, read the fifos from the frontends on selected channels to the central unit memory and save them on the file
				if(out) //check if there was any read error
				{
					cout<<"there was an irrecoverable read error, code "<<out<<", aborting."<<endl;
					cout<<"All events up to event "<<i<<" were saved"<<endl;			 
					break;
				}
				else
				{
		                        uint64_t pads=*(uint64_t*)(&FIFOarray[0]+116*8);
	                                for(int i=117 ; i<128 ; i++)
	                                {
                        	                pads=pads|*(uint64_t*)(&FIFOarray[0]+i*8);
                	                }
	       		                bitset<64> bitspads(pads);
		                        int nbitspads=0;     
					int pad=0;   
					for(int b=0;b<64;b++)
                        		{
						if(bitspads[b]) 
						{
		                                	nbitspads++;
							pad=b;
						}
		                        }
					if(nbitspads==1)
					{
						padcounter[pad]++;
					}

					*trigger_enable=0x00; //resets trigger
					*trigger_enable=0x01; 
					i++; 
					cout<<i<<endl;
				}
			}
		}
		auto elapsed = chrono::high_resolution_clock::now() - start; //calculate elapsed time in microsseconds
		unsigned long long microseconds = chrono::duration_cast<chrono::microseconds>(elapsed).count(); //creates microssecond long long (8 bytes) variable  
		time(&currdate);																	   
		timestamp = localtime(&currdate);				//gets current local time and date
		uint8_t tearray[6]={timestamp->tm_hour,timestamp->tm_min,timestamp->tm_sec,timestamp->tm_mday,timestamp->tm_mon,timestamp->tm_year}; //creates current local time and date array
		cout<<numev<<endl<<flush;  
		cout<<"aquisition began at "<<(int)tsarray[0]<<":"<<(int)tsarray[1]<<":"<<(int)tsarray[2]<<"	"<<(int)tsarray[3]<<"/"<<(int)tsarray[4]+1<<"/"<<(int)tsarray[5]+1900<<endl<<flush;
		cout<<"aquisition ended at "<<(int)tearray[0]<<":"<<(int)tearray[1]<<":"<<(int)tearray[2]<<"	"<<(int)tearray[3]<<"/"<<(int)tearray[4]+1<<"/"<<(int)tearray[5]+1900<<endl<<flush;
		cout <<"acquisition time was "<<(microseconds/1000000.0)<<" seconds"<<endl<<flush;
		out=write_from_array(sttm_off,33,1,channels); //stops hit state machine in frontend in selected channels
		cout<<"Address 33 (stop hit stt machine) status: "<<out<<endl<<flush;  //prints the write status (should be 0)
		*trigger_enable=0x00;	//disables central unit trigger (should be futile, it automatically stops after each trigger)		   
		for(int i=0;i<64;i++)
		{
			cout<<"maroc channel "<<i<<" = "<<padcounter[i]<<endl<<flush;
		}
		unmap_memory();		    //unmaps memory
		return 0;			    //returns 0 (everything was successful) 
	}
	else
	{
				cout<<"This program must receive exactly 4 arguments (enabled interface channels and number of events"<<endl<<flush;
	}
}
