#include <iomanip>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <cstdlib>
#include <iostream>
#include <math.h>
#include <unistd.h>
#include <fstream>
#include <bitset>
#include <vector>

using namespace std;


int main(int argc, char* argv[])
{   
	string acq_date(argv[1]);
	string raw_path="/data/DATA_"+acq_date+"/HOD_RAW/";
	string acq_path="/data/DATA_"+acq_date+"/ACQ.txt";
	string reduced_path="/data/DATA_"+acq_date+"/reduced_bins/";
	fstream auxfile(acq_path, ios_base::in); //open aux text file 
	vector  <string> bin_files;
	string line;
	getline(auxfile,line);  
	bitset<4> channels(line);			//converts the 4 bits from a string of chars to a bitset
	uint8_t selected=channels[0]+channels[1]*2+channels[2]*4+channels[3]*8;
	uint8_t nchannels=channels[0]+channels[1]+channels[2]+channels[3]; //number of enabled channels
	getline(auxfile,line);
	ulong req_numev=strtoul(line.c_str(),NULL,10);
	cout<<req_numev<<" events were required in the acquisiton"<<endl<<flush;
	cout<<"getting bin files list"<<endl<<flush;
	while(getline(auxfile,line))
	{
		vector  <string> tokens;
		istringstream iss(line);
		string token;
		getline(iss, token, '\t');
		if(strcmp(token.c_str(),"FO")==0)
		{
			getline(iss, token, '\t');
			bin_files.push_back(token);
			cout<<"appending file "<<token<<endl<<flush;
		}
	}
	ulong obt_numev;							 //create variable for obtained number of events
	uint8_t readarray[4114];				 //create array for reading FIFO blocks from file
	//create arrays for bin statistics of frontends in each interface channel
	uint64_t bins1[128]={0};
	uint64_t bins2[128]={0};
	uint64_t bins3[128]={0};
	uint64_t bins4[128]={0};
	uint64_t total1=0; //create variables for the total of bins with at least one '1' in each channel
	uint64_t total2=0;
	uint64_t total3=0;
	uint64_t total4=0; 	

	for (string name : bin_files)
	{
		ifstream bin((raw_path+name), std::ios::binary); //open raw binary file
		if(bin)
		{
			while(true)
			{
				bin.read((char*)readarray,nchannels*1024+18); //read event block
				if(bin.eof()) //tried to read after end of file
				{
					bin.close();
					bin.clear();
					break;
				}
				obt_numev++;
				if(obt_numev%1731==0) //print progress at every 1731 events
				{
					cout<<obt_numev<<"\r"<<flush;
				}
				int i=0;
				if(channels[0])  //if channel is enabled
				{
					for(int j=0;j<128;j++)			   //read each position in the FIFO
					{
						uint64_t pads=*(uint64_t*)(readarray+j*8); //get the 64 pads	
						int hasone=(pads>0);					   //check if at least one had a '1'
						total1+=hasone;							   //increment the total amount of bins with '1's in this channel in the whole acquisiton
						bins1[j]+=hasone;						   //increment the amount of times this bin had one '1' in the whole acquisition
					}
					i+=1024;
				}
				if(channels[1]) 
				{
					for(int j=0;j<128;j++)
					{
						uint64_t pads=*(uint64_t*)(readarray+i+j*8);
						int hasone=(pads>0);
						total2+=hasone;
						bins2[j]+=hasone;
					}
					i+=1024;
				}
				if(channels[2]) 
				{
					for(int j=0;j<128;j++)
					{
						uint64_t pads=*(uint64_t*)(readarray+i+j*8);
						int hasone=(pads>0);
						total3+=hasone;
						bins3[j]+=hasone;
					}
					i+=1024;
				}
				if(channels[3]) 
				{
					for(int j=0;j<128;j++)
					{
						uint64_t pads=*(uint64_t*)(readarray+i+j*8);
						int hasone=(pads>0);
						total4+=hasone;
						bins4[j]+=hasone;
					}
				}
			}
		}
	}
	
	cout<<obt_numev<<" events were read in the files specified in the acquisition file"<<endl<<flush;
	if(channels[0]){cout<<"number of bins with at least one '1' in channel1 in the whole acquisition: "<<total1<<endl<<flush;}
	if(channels[1]){cout<<"number of bins with at least one '1' in channel2 in the whole acquisition: "<<total2<<endl<<flush;}
	if(channels[2]){cout<<"number of bins with at least one '1' in channel3 in the whole acquisition: "<<total3<<endl<<flush;}
	if(channels[3]){cout<<"number of bins with at least one '1' in channel4 in the whole acquisition: "<<total4<<endl<<flush;}
	cout<<"the percentage of 1s in each FIFO position, from the total of each respective channel is:"<<endl<<flush;
	for(int i=0;i<128;i++)
	{
		if(channels[0])
		{
			float percent1=(float)(100*bins1[i])/(float)total1;
			cout<<"bin "<<i<<" channel 1="<<percent1<<"%"<<"	";
		}
		if(channels[1])
		{
			float percent2=(float)(100*bins2[i])/(float)total2;
			cout<<"bin "<<i<<" channel 2="<<percent2<<"%"<<"	";
		}
		if(channels[2])
		{
			float percent3=(float)(100*bins3[i])/(float)total3;
			cout<<"bin "<<i<<" channel 3="<<percent3<<"%"<<"	";
		}
		if(channels[3])
		{
			float percent4=(float)(100*bins4[i])/(float)total4;
			cout<<"bin "<<i<<" channel 4="<<percent4<<"%";
		}
		cout<<endl<<flush;
	}
	int beginbin1=0;
	int beginbin2=0;
	int beginbin3=0;
	int beginbin4=0;
	int size=0;
	while(true)
	{
		cout<<"type the desired window size (1 to 128):"<<endl<<flush; 
		cin >> size;
		cin.get();
		if(size<1||size>128)
		{
			cout<<"invalid input."<<endl<<flush; 
		}
		else
		{
			break;
		}
	}

	while(true&&channels[0])
	{
		cout<<"type in which bin you wish to begin the window at channel 1 (from "<<0<<" to "<<(127-size+1)<<"):"<<endl<<flush; 
				cin >> beginbin1;
		cin.get();
		if(beginbin1<0||beginbin1>(127-size+1))
		{
			cout<<"invalid input."<<endl<<flush; 
		}
		else
		{
			break;
		}
	}
	while(true&&channels[1])
	{
			cout<<"type in which bin you wish to begin the window at channel 2 (from "<<0<<" to "<<(127-size+1)<<"):"<<endl<<flush;
			cin >> beginbin2;
			cin.get();
			if(beginbin2<0||beginbin2>(127-size+1))
			{
					cout<<"invalid input."<<endl<<flush;
			}
			else
			{
					break;
			}
	}
	while(true&&channels[2])
	{
			cout<<"type in which bin you wish to begin the window at channel 3 (from "<<0<<" to "<<(127-size+1)<<"):"<<endl<<flush;
			cin >> beginbin3;
			cin.get();
			if(beginbin3<0||beginbin3>(127-size+1))
			{
					cout<<"invalid input."<<endl<<flush;
			}
			else
			{
					break;
			}
	}
	while(true&&channels[3])
	{
			cout<<"type in which bin you wish to begin the window at channel 4 (from "<<0<<" to "<<(127-size+1)<<"):"<<endl<<flush;
			cin >> beginbin4;
			cin.get();
			if(beginbin4<0||beginbin4>(127-size+1))
			{
					cout<<"invalid input."<<endl<<flush;
			}
			else
			{
					break;
			}
	}
	
	line="RH\t HOD_EVT_"+acq_date+".bin\t"+to_string(obt_numev)+"\t"+to_string(size)+"\t"+to_string(beginbin1)+"\t"+to_string(beginbin2)+"\t"+to_string(beginbin3)+"\t"+to_string(beginbin4)+"\n"; 
	auxfile.close();
	auxfile.clear();
	auxfile.open(acq_path, ios::app); //open aux text file 
	auxfile.write(line.data(),line.size());
	auxfile.close();
	ofstream reduced(reduced_path+"HOD_EVT_"+acq_date+".bin", std::ios::binary);
	reduced.write((char*)&selected,1);
	reduced.write((char*)&beginbin1,1);
	reduced.write((char*)&beginbin2,1);
	reduced.write((char*)&beginbin3,1);
	reduced.write((char*)&beginbin4,1);
	reduced.write((char*)&size,1);
	obt_numev=0;

	for (string name : bin_files)
	{
		ifstream bin((raw_path+name), std::ios::binary); //open raw binary file
		if(bin)
		{
			while(true)
			{
				bin.read((char*)readarray,nchannels*1024+18); //read event block
				if(bin.eof()) //tried to read after end of file
				{
					bin.close();
					bin.clear();
					break;
				}
				obt_numev++;
				if(obt_numev%1731==0) //print progress at every 1731 events
				{
					cout<<obt_numev<<"\r"<<flush;
				}
				int i=0;
				if(channels[0])  //if channel is enabled
				{
					reduced.write((char*)(readarray+beginbin1*8),size*8);									
					i+=1024;
				}
				if(channels[1])  //if channel is enabled
				{
					reduced.write((char*)(readarray+i+beginbin2*8),size*8);									
					i+=1024;
				}
				if(channels[2])  //if channel is enabled
				{
					reduced.write((char*)(readarray+i+beginbin3*8),size*8);   
					i+=1024;								 
				}
				if(channels[3])  //if channel is enabled
				{
					reduced.write((char*)(readarray+i+beginbin4*8),size*8);									
					i+=1024;
				}
				reduced.write((char*)(readarray+i),18);	
			}
		}
	}
	reduced.close();
	cout<<"finished."<<endl<<flush;
}
