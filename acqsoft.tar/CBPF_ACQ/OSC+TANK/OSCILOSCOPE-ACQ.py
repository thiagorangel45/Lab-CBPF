from RsInstrument.RsInstrument import RsInstrument, BinIntFormat
from time import time
from time import sleep
import time
import os


def configchan():
	rth.write_str("CHAN1:SCAL 0.02")
	rth.write_str("CHAN1:POS 4.0")
	rth.write_str("CHAN1:COUP DC") #configura a terminacao para 50 ohm


def configtime():
	rth.write_str("TIM:SCAL 0.00000003")
	rth.write_str("TIM:POS -0.00000024")


def setexttrigger():
	rth.write_str("TRIG:A:LEV5:VAL 0.4")
	rth.write_str("TRIG:A:MODE NORM")
	rth.write_str("TRIG:A:SOUR EXT")


def setleveltrigger():
	rth.write_str("TRIG:A:LEV1:VAL -0.01")
	rth.write_str("TRIG:A:TYPE EDGE")
	rth.write_str("TRIG:A:EDGE:SLOP NEG")
	rth.write_str("TRIG:A:MODE NORM")




def mainloop():
	rth.clear_status()
	rth.reset()
	configchan()
	configtime()
	setexttrigger()
	j = 0
	num_aq = 50000 # int(input('Quantidade de aquisicoes: '))
	tempo_inicial = (time.time())
	sets = open('settings.txt','a')
	sets.write('\n\nTempo inicial da aquisicao:%s' %(tempo_inicial))
	sets.close()
	ch1_scale = rth.query_float("CHAN1:SCAL?")
	ch1_offs = rth.query_float("CHAN1:OFFS?")
	ch1_pos = rth.query_float("CHAN1:POS?")
	rth.write_str("FORM:DATA UINT,16")
	rth.bin_int_numbers_format = BinIntFormat.Integer16_2bytes
	rth.data_chunk_size = 100000  # transfer in blocks of 100k bytes (default)
	init=0
	end=1800
	binario_data = open('binario.bin','ab')

	while (j < num_aq):
		try:
			rth.write_str_with_opc("SING",4731) #modified version of single that doesn't wait until a trigger, it only sends the comand
			os.system("/data/EAFExp2023/trig-enabler 1") #set trigger to one
			rth.write_str_with_opc("SING",4732)	 #modified version of single that finishes waiting for the trigger
			data_bin = rth.query_bin_or_ascii_int_list("CHAN:DATA?")
			for i in range(init,end,1):      
				binario_data.write((data_bin[i].to_bytes(2,'big',signed=True)))
		   	j += 1   
 			print(j,end='\r')
		except:
			print('\n\tAconteceu um problema! O sistema vai pausar�por 10 segundos antes de retormar.')
			for i in range(init,end,1):      
				binario_data.write(((0).to_bytes(2,'big',signed=True))) #enche o evento correspondente de zeros no binario do osciloscopio, pra manter o passo
			sleep(10)
			j += 1
			print(j,end='\r')


	binario_data.close()
	tempo_final = (time.time())
	yres = rth.query_float("CHAN1:DATA:YRES?")
	yor = rth.query_float("CHAN1:DATA:YOR?")
	xor = rth.query_float("CHAN1:DATA:XOR?")
	xinc = rth.query_float("CHAN1:DATA:XINC?")
	yinc = rth.query_float("CHAN1:DATA:YINC?")
	sets = open('settings.txt','a')
	sets.write('\nTempo final da aquisicao:%s' %(tempo_final))
	sets.write('\nYres:%s' %str(yres))
	sets.write('\nYor:%s' %str(yor))
	sets.write('\nXor:%s' %str(xor))
	sets.write('\nYinc:%s' %str(yinc))
	sets.write('\nXinc:%s' %str(xinc))
	sets.write('\nInicio dos samp:%s' %str(init))
	sets.write('\nFinal dos samp:%s' %str(end))
	sets.close()
	rth.close()


rth = None
try:
	rth = RsInstrument('TCPIP::152.84.120.161::INSTR', True, False)
	rth.visa_timeout = 60000000  # Timeout for VISA Read Operations (milliseconds) -> padr  o60000
	rth.opc_timeout = 20000000  # Timeout for opc-synchronised operations (miliseconds) -> padr  o 30000
	rth.instrument_status_checking = True  # Error check after each command
	mainloop()
except Exception as ex:
	print('Error initializing the instrument session:\n' + ex.args[0])
	exit()
