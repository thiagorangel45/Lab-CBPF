#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <cstdlib>
#include <iostream>
#include <math.h>
#include <unistd.h>
#include <fstream>

using namespace std;

int mem_fd, address_block_size, RW_block_size;

void *RW_block, *address_block; 
void *rpc1_nbytes, *rpc2_nbytes, *rpc3_nbytes, *rpc4_nbytes;
void *rpc1_data, *rpc2_data, *rpc3_data, *rpc4_data;
void *rpc1_sumcheck, *rpc2_sumcheck, *rpc3_sumcheck, *rpc4_sumcheck;
void *rpc1_icheck, *rpc2_icheck, *rpc3_icheck, *rpc4_icheck;
void *rpc1_address, *rpc2_address, *rpc3_address, *rpc4_address;
void *rpc1_confirm, *rpc2_confirm, *rpc3_confirm, *rpc4_confirm;
uint8_t *trigger_read, *trigger_enable, *trigger_mode;
uint16_t *trigger_logic_bits;
uint32_t *lts_id;

long pagesize;

int read_to_array(uint8_t* outarray,uint8_t address,uint16_t nbytes, bitset<4> rpcs) //returns 0 if no error, all other values correspond to unrecovered errors
{
	bitset<12> out(0); 	//output variable
	address+=0x80; 		//sets the MSB to 1, as required for reading
	int rpc1_err=0, rpc2_err=0, rpc3_err=0, rpc4_err=0; //error counter
	int rpc1_stat=rpcs[0], rpc2_stat=rpcs[1], rpc3_stat=rpcs[2], rpc4_stat=rpcs[3]; //0=not to be read, 1=to be read, 2=failure in last attempt
	
	uint8_t *slot2; //declare the pointers for the slots in the output array
	uint8_t *slot3;
	uint8_t *slot4;

	//define the beginning of the slots (in the output array) to which each RPC data must be copied, in case there's more than 1 being read.	   
	//Ps.: The comparisons in these if statements are an order of magnitude faster than a memory access (because of the O_SYNC option in mmap), thus its worth it to add if statements to avoid uneccessary accesses
	if(rpc2_stat) 
	{
		slot2=outarray+nbytes*rpc1_stat; 
	}
	if(rpc3_stat)
	{
		slot3=outarray+nbytes*(rpc1_stat+rpc2_stat);
	}
	if(rpc4_stat)
	{
		slot4=outarray+nbytes*(rpc1_stat+rpc2_stat+rpc3_stat);		
	}

	while(true) //loop that makes up to 3 attempts at reading in case of recoverable errors (error in the read-request frame) 
	{

		//Prepare the read request firstly by setting the address register of each enabled RPC to 0 and setting the nbytes value

		if(rpc1_stat)
		{
			*(uint16_t*)rpc1_sumcheck=0xFF; 
			*(uint16_t*)rpc1_icheck=0; 
			*(uint8_t*)rpc1_address=0; 		//clear address
			*(uint16_t*)rpc1_nbytes=nbytes-1;   //set nbytes
		}
		if(rpc2_stat)
		{ 
						*(uint16_t*)rpc2_sumcheck=0xFF;
						*(uint16_t*)rpc2_icheck=0;
			*(uint8_t*)rpc2_address=0; 			
			*(uint16_t*)rpc2_nbytes=nbytes-1;   
		} 
		if(rpc3_stat)
		{ 
						*(uint16_t*)rpc3_sumcheck=0xFF;
						*(uint16_t*)rpc3_icheck=0;
			*(uint8_t*)rpc3_address=0; 			
			*(uint16_t*)rpc3_nbytes=nbytes-1;   	
		}	
		if(rpc4_stat)
		{ 
						*(uint16_t*)rpc4_sumcheck=0xFF;
						*(uint16_t*)rpc4_icheck=0;
			*(uint8_t*)rpc4_address=0; 			
			*(uint16_t*)rpc4_nbytes=nbytes-1;
		} 

		//Set the address register to the address value in order to send the read requests. This is done separatedly to reduce the delay between the sending of the requests by the central unit

		if (rpc1_stat)
		{
			*(uint8_t*)rpc1_address=address;
		}
		if (rpc2_stat)
		{
			*(uint8_t*)rpc2_address=address;
		}
		if (rpc3_stat)
		{
			*(uint8_t*)rpc3_address=address;
		}
		if (rpc4_stat)
		{
			*(uint8_t*)rpc4_address=address;
		}
						
		
		//loops copying every RPC that answered, to a max num of iterations of 1000*nbytes, to give enough time for all to answer
		
		for(int i=0;;i++)	
		{
			
			if(*(uint8_t*)rpc1_confirm !=0 && rpc1_stat==1)
			{
				if(*(uint8_t*)rpc1_confirm == 254 && *(uint16_t*)rpc1_sumcheck == 0 && *(uint16_t*)rpc1_icheck != 0) // responded with success and checksum difference was zero
				{	
					copy((uint8_t*)rpc1_data,(uint8_t*)(rpc1_data+nbytes),outarray);  //copies the data		
					rpc1_stat=0; //sucess 
				}
				else if(*(uint8_t*)rpc1_confirm == 255)
				{
					rpc1_stat=2; //recoverable error, the frontend didn't get the request properly and didn't send data
					rpc1_err++; //increments the recoverable error variable
				}	
				else
				{
					rpc1_stat=3; //the frontend sent data but it was wrong, this is irrecoverable, for it has emptied its FIFO		
				}
			}	
			
			if(*(uint8_t*)rpc2_confirm !=0 && rpc2_stat==1)
			{
				if(*(uint8_t*)rpc2_confirm == 254 && *(uint16_t*)rpc2_sumcheck == 0  && *(uint16_t*)rpc2_icheck != 0) 
				{	
					copy((uint8_t*)rpc2_data,(uint8_t*)(rpc2_data+nbytes),slot2);  
					rpc2_stat=0; 
				}
				else if(*(uint8_t*)rpc2_confirm == 255)
				{
					rpc2_stat=2;
					rpc2_err++;
				}	
				else
				{
					rpc2_stat=3; 
				}
			}			
			
			
			if(*(uint8_t*)rpc3_confirm !=0 && rpc3_stat==1)
			{
				if(*(uint8_t*)rpc3_confirm == 254 && *(uint16_t*)rpc3_sumcheck == 0  && *(uint16_t*)rpc3_icheck != 0) 
				{	
					copy((uint8_t*)rpc3_data,(uint8_t*)(rpc3_data+nbytes),slot3);  
					rpc3_stat=0; 
				}
				else if(*(uint8_t*)rpc3_confirm == 255)
				{
					rpc3_stat=2;
					rpc3_err++;
				}	
				else
				{
					rpc3_stat=3; 
				}
			}			
						
			
			if(*(uint8_t*)rpc4_confirm !=0 && rpc4_stat==1)
			{
				if(*(uint8_t*)rpc4_confirm == 254 && *(uint16_t*)rpc4_sumcheck == 0  && *(uint16_t*)rpc4_icheck != 0) 
				{	
					copy((uint8_t*)rpc4_data,(uint8_t*)(rpc4_data+nbytes),slot4);  
					rpc4_stat=0; 
				}
				else if(*(uint8_t*)rpc4_confirm == 255)
				{
					rpc4_stat=2;
					rpc4_err++;
				}	
				else
				{
					rpc4_stat=3; 
				}
			}				
			if((rpc1_stat!=1)&&(rpc2_stat!=1)&&(rpc3_stat!=1)&&(rpc4_stat!=1)) //if all have answered something
			{	
				break;
			}			
			if(i==1000*nbytes) //if at least one RPC timed out
			{		
				out[11]=(rpc4_stat==3); //sets to 1 if this rpc had an error type 3 in this loop, and to 0 if not.
				out[10]=(rpc3_stat==3);
				out[9]= (rpc2_stat==3);
				out[8]= (rpc1_stat==3);	
				out[7]=(rpc4_stat==1); //Sets this bit to 1 if this rpc hasn't answered in this loop, and to 0 if not.
				out[6]=(rpc3_stat==1);
				out[5]=(rpc2_stat==1);
				out[4]=(rpc1_stat==1);			
				out[3]=(rpc4_err==3); //sets this bit to 1 if this rpc had 3 type 2 failures (but answered in this loop), and to 0 if not.
				out[2]=(rpc3_err==3);
				out[1]=(rpc2_err==3);
				out[0]=(rpc1_err==3);
				return out.to_ulong();								
			}
		}
		if((rpc1_stat==0)&&(rpc2_stat==0)&&(rpc3_stat==0)&&(rpc4_stat==0)) //all had success in this attempt
		{		
			return 0;
		}
		if((rpc1_stat==3)||(rpc2_stat==3)||(rpc3_stat==3)||(rpc4_stat==3)||(rpc1_err==3)||(rpc2_err==3)||(rpc3_err==3)||(rpc4_err==3)) //at least one RPC had an irrecoverable error, but none timed out
		{	
			out[11]=(rpc4_stat==3); 
			out[10]=(rpc3_stat==3);
			out[9]= (rpc2_stat==3);
			out[8]= (rpc1_stat==3);	
			out[3]=(rpc4_err==3);  
			out[2]=(rpc3_err==3);
			out[1]=(rpc2_err==3);
			out[0]=(rpc1_err==3);	
			return out.to_ulong();
		}		
		rpc1_stat=(rpc1_stat==2); //sets to 1 (to be read) the stat of all RPCs that had type 2 failure, in order to try again
		rpc2_stat=(rpc2_stat==2);
		rpc3_stat=(rpc3_stat==2);
		rpc4_stat=(rpc4_stat==2);
	}
}


int fixed_read_to_array(uint8_t* outarray,uint8_t address,uint16_t nbytes, bitset<4> rpcs) //returns 0 if no error, all other values correspond to unrecovered errors
{
	bitset<12> out(0); 	//output variable
	address+=0x80; 		//sets the MSB to 1, as required for reading
	int rpc1_err=0, rpc2_err=0, rpc3_err=0, rpc4_err=0; //error counter
	int rpc1_stat=rpcs[0], rpc2_stat=rpcs[1], rpc3_stat=rpcs[2], rpc4_stat=rpcs[3]; //0=not to be read, 1=to be read, 2=failure in last attempt

	while(true) //loop that makes up to 3 attempts at reading in case of recoverable errors (error in the read-request frame) 
	{

		//Prepare the read request firstly by setting the address register of each enabled RPC to 0 and setting the nbytes value

		if(rpc1_stat)
		{
			*(uint16_t*)rpc1_sumcheck=0xFF; 
			*(uint16_t*)rpc1_icheck=0; 
			*(uint8_t*)rpc1_address=0; 		//clear address
			*(uint16_t*)rpc1_nbytes=nbytes-1;   //set nbytes
		}
		if(rpc2_stat)
		{ 
						*(uint16_t*)rpc2_sumcheck=0xFF;
						*(uint16_t*)rpc2_icheck=0;
			*(uint8_t*)rpc2_address=0; 			
			*(uint16_t*)rpc2_nbytes=nbytes-1;   
		} 
		if(rpc3_stat)
		{ 
						*(uint16_t*)rpc3_sumcheck=0xFF;
						*(uint16_t*)rpc3_icheck=0;
			*(uint8_t*)rpc3_address=0; 			
			*(uint16_t*)rpc3_nbytes=nbytes-1;   	
		}	
		if(rpc4_stat)
		{ 
						*(uint16_t*)rpc4_sumcheck=0xFF;
						*(uint16_t*)rpc4_icheck=0;
			*(uint8_t*)rpc4_address=0; 			
			*(uint16_t*)rpc4_nbytes=nbytes-1;
		} 

		//Set the address register to the address value in order to send the read requests. This is done separatedly to reduce the delay between the sending of the requests by the central unit

		if (rpc1_stat)
		{
			*(uint8_t*)rpc1_address=address;
		}
		if (rpc2_stat)
		{
			*(uint8_t*)rpc2_address=address;
		}
		if (rpc3_stat)
		{
			*(uint8_t*)rpc3_address=address;
		}
		if (rpc4_stat)
		{
			*(uint8_t*)rpc4_address=address;
		}
						
		
		//loops copying every RPC that answered, to a max num of iterations of 1000*nbytes, to give enough time for all to answer
		
		for(int i=0;;i++)	
		{
			
			if(*(uint8_t*)rpc1_confirm !=0 && rpc1_stat==1)
			{
				if(*(uint8_t*)rpc1_confirm == 254 && *(uint16_t*)rpc1_sumcheck == 0 && *(uint16_t*)rpc1_icheck != 0) // responded with success and checksum difference was zero
				{	
					copy((uint8_t*)rpc1_data,(uint8_t*)(rpc1_data+nbytes),outarray);  //copies the data		
					rpc1_stat=0; //sucess 
				}
				else if(*(uint8_t*)rpc1_confirm == 255)
				{
					rpc1_stat=2; //recoverable error, the frontend didn't get the request properly and didn't send data
					rpc1_err++; //increments the recoverable error variable
				}	
				else
				{
					rpc1_stat=3; //the frontend sent data but it was wrong, this is irrecoverable, for it has emptied its FIFO		
				}
			}	
			
			if(*(uint8_t*)rpc2_confirm !=0 && rpc2_stat==1)
			{
				if(*(uint8_t*)rpc2_confirm == 254 && *(uint16_t*)rpc2_sumcheck == 0  && *(uint16_t*)rpc2_icheck != 0) 
				{	
					copy((uint8_t*)rpc2_data,(uint8_t*)(rpc2_data+nbytes),outarray+nbytes);  
					rpc2_stat=0; 
				}
				else if(*(uint8_t*)rpc2_confirm == 255)
				{
					rpc2_stat=2;
					rpc2_err++;
				}	
				else
				{
					rpc2_stat=3; 
				}
			}			
			
			
			if(*(uint8_t*)rpc3_confirm !=0 && rpc3_stat==1)
			{
				if(*(uint8_t*)rpc3_confirm == 254 && *(uint16_t*)rpc3_sumcheck == 0  && *(uint16_t*)rpc3_icheck != 0) 
				{	
					copy((uint8_t*)rpc3_data,(uint8_t*)(rpc3_data+nbytes),outarray+nbytes*2);  
					rpc3_stat=0; 
				}
				else if(*(uint8_t*)rpc3_confirm == 255)
				{
					rpc3_stat=2;
					rpc3_err++;
				}	
				else
				{
					rpc3_stat=3; 
				}
			}			
						
			
			if(*(uint8_t*)rpc4_confirm !=0 && rpc4_stat==1)
			{
				if(*(uint8_t*)rpc4_confirm == 254 && *(uint16_t*)rpc4_sumcheck == 0  && *(uint16_t*)rpc4_icheck != 0) 
				{	
					copy((uint8_t*)rpc4_data,(uint8_t*)(rpc4_data+nbytes),outarray+nbytes*3);  
					rpc4_stat=0; 
				}
				else if(*(uint8_t*)rpc4_confirm == 255)
				{
					rpc4_stat=2;
					rpc4_err++;
				}	
				else
				{
					rpc4_stat=3; 
				}
			}				
			if((rpc1_stat!=1)&&(rpc2_stat!=1)&&(rpc3_stat!=1)&&(rpc4_stat!=1)) //if all have answered something
			{	
				break;
			}			
			if(i==1000*nbytes) //if at least one RPC timed out
			{		
				out[11]=(rpc4_stat==3); //sets to 1 if this rpc had an error type 3 in this loop, and to 0 if not.
				out[10]=(rpc3_stat==3);
				out[9]= (rpc2_stat==3);
				out[8]= (rpc1_stat==3);	
				out[7]=(rpc4_stat==1); //Sets this bit to 1 if this rpc hasn't answered in this loop, and to 0 if not.
				out[6]=(rpc3_stat==1);
				out[5]=(rpc2_stat==1);
				out[4]=(rpc1_stat==1);			
				out[3]=(rpc4_err==3); //sets this bit to 1 if this rpc had 3 type 2 failures (but answered in this loop), and to 0 if not.
				out[2]=(rpc3_err==3);
				out[1]=(rpc2_err==3);
				out[0]=(rpc1_err==3);
				return out.to_ulong();								
			}
		}
		if((rpc1_stat==0)&&(rpc2_stat==0)&&(rpc3_stat==0)&&(rpc4_stat==0)) //all had success in this attempt
		{		
			return 0;
		}
		if((rpc1_stat==3)||(rpc2_stat==3)||(rpc3_stat==3)||(rpc4_stat==3)||(rpc1_err==3)||(rpc2_err==3)||(rpc3_err==3)||(rpc4_err==3)) //at least one RPC had an irrecoverable error, but none timed out
		{	
			out[11]=(rpc4_stat==3); 
			out[10]=(rpc3_stat==3);
			out[9]= (rpc2_stat==3);
			out[8]= (rpc1_stat==3);	
			out[3]=(rpc4_err==3);  
			out[2]=(rpc3_err==3);
			out[1]=(rpc2_err==3);
			out[0]=(rpc1_err==3);	
			return out.to_ulong();
		}		
		rpc1_stat=(rpc1_stat==2); //sets to 1 (to be read) the stat of all RPCs that had type 2 failure, in order to try again
		rpc2_stat=(rpc2_stat==2);
		rpc3_stat=(rpc3_stat==2);
		rpc4_stat=(rpc4_stat==2);
	}
}



int write_from_array(uint8_t* inarray,uint8_t address,uint16_t nbytes, bitset<4> rpcs) //returns 0 if no error, all other values correspond to unrecoverable errors
{
	bitset<8> out(0); //output variable
	int rpc1_err=0, rpc2_err=0, rpc3_err=0, rpc4_err=0; //error counter
	int rpc1_stat=rpcs[0], rpc2_stat=rpcs[1], rpc3_stat=rpcs[2], rpc4_stat=rpcs[3]; //0=not to be written, 1=to be written, 2=failure in last attempt

	//set nbytes and copy data for all RPCs to be written, this doesn't have to be redone in re-attempts
	
	if(rpc1_stat)
	{ 
		*(uint16_t*)rpc1_nbytes=nbytes-1;   //set nbytes
		copy(inarray,inarray+nbytes,(uint8_t*)rpc1_data); //copy data
	}
	if(rpc2_stat)
	{ 		
		*(uint16_t*)rpc2_nbytes=nbytes-1;   
		copy(inarray,inarray+nbytes,(uint8_t*)rpc2_data);
	} 
	if(rpc3_stat)
	{ 
		*(uint16_t*)rpc3_nbytes=nbytes-1;  
		copy(inarray,inarray+nbytes,(uint8_t*)rpc3_data); 
	}	
	if(rpc4_stat)
	{ 		
		*(uint16_t*)rpc4_nbytes=nbytes-1;   
		copy(inarray,inarray+nbytes,(uint8_t*)rpc4_data);
	} 

	while(true) 
	{

		//sets to zero the address register of the RPCs whose stat is 1
		//ps.: The comparisons are an order of magnitude faster than the memory accesses
		
		if (rpc1_stat)
		{
			*(uint8_t*)rpc1_address=0;
		}
		if (rpc2_stat)
		{
			*(uint8_t*)rpc2_address=0;
		}
		if (rpc3_stat)
		{
			*(uint8_t*)rpc3_address=0;
		}
		if (rpc4_stat)
		{
			*(uint8_t*)rpc4_address=0;
		}
		//sets to the address value the address register of the RPCs whose stat is 1 (they are done separatedly to have the smallest delay between the commands as possible)
		if (rpc1_stat)
		{
			*(uint8_t*)rpc1_address=address;
		}
		if (rpc2_stat)
		{
			*(uint8_t*)rpc2_address=address;
		}
		if (rpc3_stat)
		{
			*(uint8_t*)rpc3_address=address;
		}
		if (rpc4_stat)
		{
			*(uint8_t*)rpc4_address=address;
		}
		
		//loops checking if all RPCs answered, for a total of nbytes*1000 iterations.
		
		for(int i=0;;i++)	
		{
			if(*(uint8_t*)rpc1_confirm !=0 && rpc1_stat==1) //check if there was any value in confirm register and if this RPC is enabled
			{
				if(*(uint8_t*)rpc1_confirm==254) //if it answered with success 
				{		
					rpc1_stat=0; //doesn't need to be checked again
				}	
				else
				{
					rpc1_stat=2;  //failed
					rpc1_err++;  //increment failure counter
				}
			}	
				
			if(*(uint8_t*)rpc2_confirm !=0 && rpc2_stat==1)
			{
				if(*(uint8_t*)rpc2_confirm==254)
				{
					rpc2_stat=0;
				}	
				else
				{
					rpc2_stat=2;
					rpc2_err++;
				}
			}	
						
			if(*(uint8_t*)rpc3_confirm !=0 && rpc3_stat==1)
			{
				if(*(uint8_t*)rpc3_confirm==254)
				{
					rpc3_stat=0;
				}	
				else
				{
					rpc3_stat=2;
					rpc3_err++;
				}
			}			
			
			if(*(uint8_t*)rpc4_confirm !=0 && rpc4_stat==1)
			{
				if(*(uint8_t*)rpc4_confirm==254)
				{
					rpc4_stat=0;
				}	
				else
				{
					rpc4_stat=2;
					rpc4_err++;
				}
			}		
				
			if((rpc1_stat!=1)&&(rpc2_stat!=1)&&(rpc3_stat!=1)&&(rpc4_stat!=1)) //if all have answered something in this loop
			{	
				break;
			}
			if(i==1000*nbytes) //if at least one RPC timed out
			{		
				out[7]=(rpc4_stat==1); //Sets this bit to 1 if this rpc hasn't answered in this loop, and to 0 if not.
				out[6]=(rpc3_stat==1);
				out[5]=(rpc2_stat==1);
				out[4]=(rpc1_stat==1);			
				out[3]=(rpc4_err==3); //sets this bit to 1 if this rpc had 3 failures (but answered in this loop), and to 0 if not.
				out[2]=(rpc3_err==3);
				out[1]=(rpc2_err==3);
				out[0]=(rpc1_err==3);
				return out.to_ulong();								
			}
		}
		if((rpc1_stat==0)&&(rpc2_stat==0)&&(rpc3_stat==0)&&(rpc4_stat==0)) //all had success in this attempt
		{		
			return 0;
		}
		else if((rpc1_err==3)||(rpc2_err==3)||(rpc3_err==3)||(rpc4_err==3)) //at least one of the RPCs had 3 consecutive errors, but none timed out
		{
				out[3]=(rpc4_err==3);
				out[2]=(rpc3_err==3);
				out[1]=(rpc2_err==3);
				out[0]=(rpc1_err==3);	
				return out.to_ulong();
		}
		rpc1_stat=(rpc1_stat==2); //sets to 1 (to be read) all stats that were set to 2 (failure), in order to try again
		rpc2_stat=(rpc2_stat==2);
		rpc3_stat=(rpc3_stat==2);
		rpc4_stat=(rpc4_stat==2);
	}
}



int read_to_file(ofstream &file,uint8_t address,uint16_t nbytes, bitset<4> rpcs) //returns 0 if no error, all other values correspond to unrecovered errors
{
	bitset<12> out(0); 	//output variable
	address+=0x80; 		//sets the MSB to 1, as required for reading
	int rpc1_err=0, rpc2_err=0, rpc3_err=0, rpc4_err=0; //error counter
	int rpc1_stat=rpcs[0], rpc2_stat=rpcs[1], rpc3_stat=rpcs[2], rpc4_stat=rpcs[3]; //0=not to be read, 1=to be read, 2=failure in last attempt
	long currpos = file.tellp(); //get position of file pointer at when the function was called
	int slot2=nbytes*rpc1_stat; //declare and initialize the variables for the offsets of the slots in the output file
	int slot3=nbytes*(rpc1_stat+rpc2_stat);
	int slot4=nbytes*(rpc1_stat+rpc2_stat+rpc3_stat);

	while(true) //loop that makes up to 3 attempts at reading in case of recoverable errors (error in the read-request frame) 
	{

		//Prepare the read request firstly by setting the address register of each enabled RPC to 0 and setting the nbytes value

		if(rpc1_stat)
		{
						*(uint16_t*)rpc1_sumcheck=0xFF;
						*(uint16_t*)rpc1_icheck=0;
			*(uint8_t*)rpc1_address=0; 			//clear address
			*(uint16_t*)rpc1_nbytes=nbytes-1;   //set nbytes
		}
		if(rpc2_stat)
		{ 
						*(uint16_t*)rpc2_sumcheck=0xFF;
						*(uint16_t*)rpc2_icheck=0;
			*(uint8_t*)rpc2_address=0; 			
			*(uint16_t*)rpc2_nbytes=nbytes-1;   
		} 
		if(rpc3_stat)
		{
						*(uint16_t*)rpc3_sumcheck=0xFF;
						*(uint16_t*)rpc3_icheck=0;
			*(uint8_t*)rpc3_address=0; 			
			*(uint16_t*)rpc3_nbytes=nbytes-1;   	
		}	
		if(rpc4_stat)
		{ 
						*(uint16_t*)rpc4_sumcheck=0xFF;
						*(uint16_t*)rpc4_icheck=0;
			*(uint8_t*)rpc4_address=0; 			
			*(uint16_t*)rpc4_nbytes=nbytes-1;
		} 

		//Set the address register to the address value in order to send the read requests. This is done separatedly to reduce the delay between the sending of the requests by the central unit

		if (rpc1_stat)
		{
			*(uint8_t*)rpc1_address=address;
		}
		if (rpc2_stat)
		{
			*(uint8_t*)rpc2_address=address;
		}
		if (rpc3_stat)
		{
			*(uint8_t*)rpc3_address=address;
		}
		if (rpc4_stat)
		{
			*(uint8_t*)rpc4_address=address;
		}
						
		
		//loops copying every RPC that answered, to a max num of iterations of 1000*nbytes, to give enough time for all to answer
		
		for(int i=0;;i++)	
		{
			
			if(*(uint8_t*)rpc1_confirm !=0 && rpc1_stat==1)
			{
				if(*(uint8_t*)rpc1_confirm == 254 && *(uint16_t*)rpc1_sumcheck == 0  && *(uint16_t*)rpc1_icheck != 0) // responded with success and checksum difference was zero
				{	
							file.seekp(currpos);
					file.write((char*)rpc1_data,nbytes);
					rpc1_stat=0; //sucess 
				}
				else if(*(uint8_t*)rpc1_confirm == 255)
				{
					rpc1_stat=2; //recoverable error, the frontend didn't get the request properly and didn't send data
					rpc1_err++; //increments the recoverable error variable
				}	
				else
				{
					rpc1_stat=3; //the frontend sent data but it was wrong, this is irrecoverable, for it has emptied its FIFO		
				}
			}	
			
			if(*(uint8_t*)rpc2_confirm !=0 && rpc2_stat==1)
			{
				if(*(uint8_t*)rpc2_confirm == 254 && *(uint16_t*)rpc2_sumcheck == 0  && *(uint16_t*)rpc2_icheck != 0) 
				{	
							file.seekp(slot2+currpos);
					file.write((char*)rpc2_data,nbytes);
					rpc2_stat=0; 
				}
				else if(*(uint8_t*)rpc2_confirm == 255)
				{
					rpc2_stat=2;
					rpc2_err++;
				}	
				else
				{
					rpc2_stat=3; 
				}
			}			
			
			
			if(*(uint8_t*)rpc3_confirm !=0 && rpc3_stat==1)
			{
				if(*(uint8_t*)rpc3_confirm == 254 && *(uint16_t*)rpc3_sumcheck == 0  && *(uint16_t*)rpc3_icheck != 0) 
				{	
							file.seekp(slot3+currpos);
					file.write((char*)rpc3_data,nbytes);
					rpc3_stat=0; 
				}
				else if(*(uint8_t*)rpc3_confirm == 255)
				{
					rpc3_stat=2;
					rpc3_err++;
				}	
				else
				{
					rpc3_stat=3; 
				}
			}			
						
			
			if(*(uint8_t*)rpc4_confirm !=0 && rpc4_stat==1)
			{
				if(*(uint8_t*)rpc4_confirm == 254 && *(uint16_t*)rpc4_sumcheck == 0  && *(uint16_t*)rpc4_icheck != 0) 
				{	
							file.seekp(slot4+currpos);
					file.write((char*)rpc4_data,nbytes);  
					rpc4_stat=0; 
				}
				else if(*(uint8_t*)rpc4_confirm == 255)
				{
					rpc4_stat=2;
					rpc4_err++;
				}	
				else
				{
					rpc4_stat=3; 
				}
			}				
			if((rpc1_stat!=1)&&(rpc2_stat!=1)&&(rpc3_stat!=1)&&(rpc4_stat!=1)) //if all have answered something
			{	
				break;
			}			
			if(i==1000*nbytes) //if at least one RPC timed out
			{		
				out[11]=(rpc4_stat==3); //sets to 1 if this rpc had an error type 3 in this loop, and to 0 if not.
				out[10]=(rpc3_stat==3);
				out[9]= (rpc2_stat==3);
				out[8]= (rpc1_stat==3);	
				out[7]=(rpc4_stat==1); //Sets this bit to 1 if this rpc hasn't answered in this loop, and to 0 if not.
				out[6]=(rpc3_stat==1);
				out[5]=(rpc2_stat==1);
				out[4]=(rpc1_stat==1);			
				out[3]=(rpc4_err==3); //sets this bit to 1 if this rpc had 3 type 2 failures (but answered in this loop), and to 0 if not.
				out[2]=(rpc3_err==3);
				out[1]=(rpc2_err==3);
				out[0]=(rpc1_err==3);
				file.seekp(currpos); // set file pointer back to the original position 
				return out.to_ulong();								
			}
		}
		if((rpc1_stat==0)&&(rpc2_stat==0)&&(rpc3_stat==0)&&(rpc4_stat==0)) //all had success in this attempt
		{	
			file.seekp(currpos+nbytes*(rpcs[0]+rpcs[1]+rpcs[2]+rpcs[3])); // set file pointer to the end of the written block
			return 0;
		}
		if((rpc1_stat==3)||(rpc2_stat==3)||(rpc3_stat==3)||(rpc4_stat==3)||(rpc1_err==3)||(rpc2_err==3)||(rpc3_err==3)||(rpc4_err==3)) //at least one RPC had an irrecoverable error, but none timed out
		{	
			out[11]=(rpc4_stat==3); 
			out[10]=(rpc3_stat==3);
			out[9]= (rpc2_stat==3);
			out[8]= (rpc1_stat==3);	
			out[3]=(rpc4_err==3);  
			out[2]=(rpc3_err==3);
			out[1]=(rpc2_err==3);
			out[0]=(rpc1_err==3);	
			file.seekp(currpos); // set file pointer back to the original position
			return out.to_ulong();
		}		
		rpc1_stat=(rpc1_stat==2); //sets to 1 (to be read) the stat of all RPCs that had type 2 failure, in order to try again
		rpc2_stat=(rpc2_stat==2);
		rpc3_stat=(rpc3_stat==2);
		rpc4_stat=(rpc4_stat==2);
	}
}


int write_from_file(ifstream &file,uint8_t address,uint16_t nbytes, bitset<4> rpcs) //returns 0 if no error, all other values correspond to unrecoverable errors
{
	bitset<8> out(0); //output variable
	int rpc1_err=0, rpc2_err=0, rpc3_err=0, rpc4_err=0; //error counter
	int rpc1_stat=rpcs[0], rpc2_stat=rpcs[1], rpc3_stat=rpcs[2], rpc4_stat=rpcs[3]; //0=not to be written, 1=to be written, 2=failure in last attempt

	uint8_t *master = (uint8_t*)rpc1_data; 
	 
	if(rpc1_stat) //define the lowest enabled RPC as the "master" from which the system will copy to others after reading file
	{
		file.read((char*)master,nbytes); //read the file into the memory area of this RPC
		*(uint16_t*)rpc1_nbytes=nbytes-1;  //nbytes has to be set for the master here
	}
	else if(rpc2_stat) 
	{
		master=(uint8_t*)rpc2_data;
		file.read((char*)master,nbytes);
		*(uint16_t*)rpc2_nbytes=nbytes-1;  
	}
	else if(rpc3_stat)
	{
		master=(uint8_t*)rpc3_data;
		file.read((char*)master,nbytes);
		*(uint16_t*)rpc3_nbytes=nbytes-1;  
	}
	else if(rpc4_stat)	
	{
		master=(uint8_t*)rpc4_data;
		file.read((char*)master,nbytes);
		*(uint16_t*)rpc4_nbytes=nbytes-1;  
	}

	//note, the first RPC cant be a "slave" because, if enabled, it's obligatorily the master

	if(rpc2_stat && master!=(uint8_t*)rpc2_data)
	{
		*(uint16_t*)rpc2_nbytes=nbytes-1;   //set nbytes
		copy(master,master+nbytes,(uint8_t*)rpc2_data); //copy data from the master
	}
	if(rpc3_stat && master!=(uint8_t*)rpc3_data)
	{
		*(uint16_t*)rpc3_nbytes=nbytes-1;   
		copy(master,master+nbytes,(uint8_t*)rpc3_data); 
	}
	if(rpc4_stat && master!=(uint8_t*)rpc4_data)
	{
		*(uint16_t*)rpc4_nbytes=nbytes-1;   
		copy(master,master+nbytes,(uint8_t*)rpc4_data); 
	}

	while(true) 
	{

		//sets to zero the address register of the RPCs whose stat is 1
		//ps.: The comparisons are an order of magnitude faster than the memory accesses
		
		if (rpc1_stat)
		{
			*(uint8_t*)rpc1_address=0;
		}
		if (rpc2_stat)
		{
			*(uint8_t*)rpc2_address=0;
		}
		if (rpc3_stat)
		{
			*(uint8_t*)rpc3_address=0;
		}
		if (rpc4_stat)
		{
			*(uint8_t*)rpc4_address=0;
		}
		//sets to the address value the address register of the RPCs whose stat is 1 (they are done separatedly to have the smallest delay between the commands as possible)
		if (rpc1_stat)
		{
			*(uint8_t*)rpc1_address=address;
		}
		if (rpc2_stat)
		{
			*(uint8_t*)rpc2_address=address;
		}
		if (rpc3_stat)
		{
			*(uint8_t*)rpc3_address=address;
		}
		if (rpc4_stat)
		{
			*(uint8_t*)rpc4_address=address;
		}
		
		//loops checking if all RPCs answered, for a total of nbytes*1000 iterations.
		
		for(int i=0;;i++)	
		{
			
			if(*(uint8_t*)rpc1_confirm !=0 && rpc1_stat==1) //check if there was any value in confirm register and if this RPC is enabled
			{
				if(*(uint8_t*)rpc1_confirm==254) //if it answered with success 
				{		
					rpc1_stat=0; //doesn't need to be checked again
				}	
				else
				{
					rpc1_stat=2;  //failed
					rpc1_err++;  //increment failure counter
				}
			}	
				
			if(*(uint8_t*)rpc2_confirm !=0 && rpc2_stat==1)
			{
				if(*(uint8_t*)rpc2_confirm==254)
				{
					rpc2_stat=0;
				}	
				else
				{
					rpc2_stat=2;
					rpc2_err++;
				}
			}	
						
			if(*(uint8_t*)rpc3_confirm !=0 && rpc3_stat==1)
			{
				if(*(uint8_t*)rpc3_confirm==254)
				{
					rpc3_stat=0;
				}	
				else
				{
					rpc3_stat=2;
					rpc3_err++;
				}
			}			
			
			if(*(uint8_t*)rpc4_confirm !=0 && rpc4_stat==1)
			{
				if(*(uint8_t*)rpc4_confirm==254)
				{
					rpc4_stat=0;
				}	
				else
				{
					rpc4_stat=2;
					rpc4_err++;
				}
			}		
				
			if((rpc1_stat!=1)&&(rpc2_stat!=1)&&(rpc3_stat!=1)&&(rpc4_stat!=1)) //if all have answered something in this loop
			{	
				break;
			}
			if(i==1000*nbytes) //if at least one RPC timed out
			{		
				out[7]=(rpc4_stat==1); //Sets this bit to 1 if this rpc hasn't answered in this loop, and to 0 if not.
				out[6]=(rpc3_stat==1);
				out[5]=(rpc2_stat==1);
				out[4]=(rpc1_stat==1);			
				out[3]=(rpc4_err==3); //sets this bit to 1 if this rpc had 3 failures (but answered in this loop), and to 0 if not.
				out[2]=(rpc3_err==3);
				out[1]=(rpc2_err==3);
				out[0]=(rpc1_err==3);
				return out.to_ulong();								
			}
		}
		if((rpc1_stat==0)&&(rpc2_stat==0)&&(rpc3_stat==0)&&(rpc4_stat==0)) //all had success in this attempt
		{		
			return 0;
		}
		else if((rpc1_err==3)||(rpc2_err==3)||(rpc3_err==3)||(rpc4_err==3)) //at least one of the RPCs had 3 consecutive errors, but none timed out
		{
				out[3]=(rpc4_err==3);
				out[2]=(rpc3_err==3);
				out[1]=(rpc2_err==3);
				out[0]=(rpc1_err==3);	
				return out.to_ulong();
		}
		rpc1_stat=(rpc1_stat==2); //sets to 1 (to be read) all stats that were set to 2 (failure), in order to try again
		rpc2_stat=(rpc2_stat==2);
		rpc3_stat=(rpc3_stat==2);
		rpc4_stat=(rpc4_stat==2);
	}
}


int map_memory()
{
	int mem_fd = open("/dev/mem", O_SYNC | O_RDWR);
	long pagesize = sysconf(_SC_PAGE_SIZE);
	if (pagesize <= 0) 
	{
		cout<<"wrong page size"<<endl<<flush;
		return 0;
	}
	if (mem_fd < 0) 
	{
		cout<<"open /dev/mem failed"<<endl<<flush;
		return 0;
	}

	RW_block_size=pagesize*ceil(0x40000.0p0/pagesize); //finds the minimal integer multiple of the pagesize that covers the entire interval of 0x40000 bytes spanned by the fronted RWS
	RW_block=mmap(NULL, RW_block_size, PROT_READ | PROT_WRITE, MAP_SHARED, mem_fd, 0xc0010000 & ~(pagesize-1)); //maps block of memory that covers the RPC RWs 
	if (RW_block == MAP_FAILED) 
	{
		cout<<"mmap failed"<<endl<<flush;
		return 0;
	}
	rpc1_nbytes=RW_block+(0xc0010000 & (pagesize-1)); 
	rpc2_nbytes=rpc1_nbytes+0x10000;
	rpc3_nbytes=rpc1_nbytes+0x20000;
	rpc4_nbytes=rpc1_nbytes+0x30000;
	rpc1_data=rpc1_nbytes+0x8;
	rpc2_data=rpc2_nbytes+0x8;
	rpc3_data=rpc3_nbytes+0x8;
	rpc4_data=rpc4_nbytes+0x8; 
	rpc1_sumcheck=rpc1_nbytes+0x2;  
	rpc2_sumcheck=rpc2_nbytes+0x2; 
	rpc3_sumcheck=rpc3_nbytes+0x2; 
	rpc4_sumcheck=rpc4_nbytes+0x2; 
	rpc1_icheck=rpc1_nbytes+0x4;
	rpc2_icheck=rpc2_nbytes+0x4;
	rpc3_icheck=rpc3_nbytes+0x4;
	rpc4_icheck=rpc4_nbytes+0x4;

			
	address_block_size=pagesize*ceil(0xEFFF.0p0/pagesize); //finds the minimal integer multiple of the pagesize that covers the entire interval of 0xEFFF bytes spanned by the frontend address bytes
	address_block=mmap(NULL, address_block_size, PROT_READ | PROT_WRITE, MAP_SHARED, mem_fd, 0xff201000 & ~(pagesize-1)); //closest page-aligned address avaliable for mapping
	if (address_block == MAP_FAILED) 
	{
		cout<<"mmap failed"<<endl<<flush;
		return 0;
	}
	rpc1_address=address_block+(0xff201000 & (pagesize-1));
	rpc2_address=rpc1_address+0x1000;
	rpc3_address=rpc1_address+0x2000;
	rpc4_address=rpc1_address+0x3000;
	rpc1_confirm=rpc1_address+0xA0C0;
	rpc2_confirm=rpc1_address+0xA0D0;
	rpc3_confirm=rpc1_address+0xA0E0;
	rpc4_confirm=rpc1_address+0xA0F0;
	trigger_read=(uint8_t*)(rpc1_address+0x9000);
	trigger_enable=(uint8_t*)(trigger_read+0x10);
	lts_id=(uint32_t*)(trigger_read+0x20);
	trigger_mode=(uint8_t*)(trigger_read+0x30);
	trigger_logic_bits=(uint16_t*)(trigger_read+0x40);
	return 1;
}

void clear_memory()
{
	for(void *cleaner=rpc1_nbytes; cleaner<(rpc1_nbytes+0x40000) ; cleaner+=4) //clears all memory in the RW area of the RPCs after mapping 
	{
		*(uint32_t*)cleaner=0; 
	}

	for(void *cleaner=rpc1_address; cleaner<(rpc1_address+0x4000) ; cleaner+=4) //clears all memory in the address area of the RPCs after mapping 
	{
		*(uint32_t*)cleaner=0; 
	}
}

int unmap_memory()
{
	if (munmap(RW_block, RW_block_size)) {
		cout<<"munmap failed"<<endl<<flush;
		return 0;
	}

	if (munmap(address_block, address_block_size)) {
		cout<<"munmap failed"<<endl<<flush;
		return 0;
	}

	if (close(mem_fd)) 
	{
		cout<<"cannot close /dev/mem"<<endl<<flush;
		return 0;
	}
	return 1;
}
