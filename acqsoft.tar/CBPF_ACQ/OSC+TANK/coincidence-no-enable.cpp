#include "config.cpp" //cointains configuration software, which in turn contains the LVDS communication and memory manager
#include <chrono>
#include <ctime>
#include <time.h>


int main(int argc, char* argv[])
{
	if(argc==5)
	{		
		map_memory();							   //maps process space memory to physical memory
		*trigger_enable=0x00;					   //disables central unit trigger output
		ofstream outfile(argv[4], std::ios::binary);  //creates and opens output binary file (overwrites if existent)
		char *ptr=NULL;							    //NULL pointer required by strtoul
		uint16_t logic=strtoul(argv[2],&ptr,16);	//convert trigger logic hex input into 16 bit integer
		ulong numev=strtoul(argv[3],&ptr,10);	    //convert number of events into unsigned long
		string chs(argv[1]);				 //string with enabled interface channels specification (4 bits written with chars, LSB is interface channel 1).
		bitset<4> channels(chs);			 //converts the 4 bits from a string of chars to a bitset
		uint8_t frontend_trig_num[1]={0x0};	 //variable with the trig number to be set on the frontend (0 for using central unit trigger)
		uint8_t sttm_on[1]={0x0F};			 //variable to start frontend state machines
		uint8_t sttm_off[1]={0xF0};			 //variable to stop frontend state machines
		uint8_t zeros[4096]={0};			 //array with zeros to write in case of frontend read error, to maintain 1:1 relationship between blocks and triggers
		int out=write_from_array(frontend_trig_num,90,1,channels);			//set the frontends in selected channels to the specified trigger number (0)
		cout<<"Address 90 (set ftend trigger) status: "<<out<<endl<<flush;	//prints the write status (should be 0)
                out=write_from_array(sttm_off,33,1,channels);                                       //stop the hit state machine
                cout<<"Address 33 (stop hit stt machine) status: "<<out<<endl<<flush;
		out=write_from_array(sttm_on,33,1,channels);					   //start the hit state machine in the frontends in the enabled channels
		cout<<"Address 33 (start hit stt machine) status: "<<out<<endl<<flush; 
		*trigger_logic_bits=logic;      //sets the central unit trigger logic
		*trigger_mode=0x4;		        //sets the central unit trigger mode  
		uint8_t selected=(uint8_t)(channels.to_ulong());
		outfile.write((char*)&selected,1);	//save the selected channels in bin file 
		long numevpos=outfile.tellp();		//gets the file pointer position to the before the number of events
		outfile.write((char*)&numev,4);		//save the number of events in bin file
		struct tm *timestamp;				//creates structure for timestamp 
		time_t currdate;								 
		time(&currdate);
		timestamp = localtime(&currdate);	//saves local date and time to timestamp variables
		uint8_t tsarray[6]={timestamp->tm_hour,timestamp->tm_min,timestamp->tm_sec,timestamp->tm_mday,timestamp->tm_mon,timestamp->tm_year}; //creates array with start timestamp variables
	  	auto start = chrono::high_resolution_clock::now(); //get current microssecond clock value for starting time  
		for(ulong i=0;i<numev;)
		{
			if(*trigger_enable==0x01 && *trigger_read==0x2)  //check trigger was enabled by external program and if there was a trigger
			{
				int out=read_to_file(outfile,32,1024,channels); //if there was a trigger, read the fifos from the frontends on selected channels to the central unit memory and save them on the file
				if(out) //check if there was any read error
				{
					long endpos=outfile.tellp(); //gets the current file pointer position. It will be before the failed block, because read_to_file() doesn't change the file pointer in case of error
					outfile.seekp(numevpos);	 //overwrite number of events with number of events up to failure
					outfile.write((char*)&i,4);
					outfile.seekp(endpos);	     //sets file pointer back to previous value
					cout<<"there was an irrecoverable read error, code "<<out<<", aborting."<<endl;
					cout<<"All events up to event "<<i<<" were saved"<<endl;			 
					break;
				}
				else
				{
					i++;  //if there was no error, increment event counter and print the event number if it reached a multiple of 100
					if((i%100)==0)
					{
						cout<<i<<endl;
					}
					*trigger_enable=0x00; //disables trigger so external program can reset it
				}
			}
		}
		auto elapsed = chrono::high_resolution_clock::now() - start; //calculate elapsed time in microsseconds
		unsigned long long microseconds = chrono::duration_cast<chrono::microseconds>(elapsed).count(); //creates microssecond long long (8 bytes) variable
		outfile.write((char*)&microseconds,8);			//writes elapsed time  
		time(&currdate);																	   
		timestamp = localtime(&currdate);				//gets current local time and date
		uint8_t tearray[6]={timestamp->tm_hour,timestamp->tm_min,timestamp->tm_sec,timestamp->tm_mday,timestamp->tm_mon,timestamp->tm_year}; //creates current local time and date array
		cout<<numev<<endl<<flush;  
		cout<<"aquisition began at "<<(int)tsarray[0]<<":"<<(int)tsarray[1]<<":"<<(int)tsarray[2]<<"	"<<(int)tsarray[3]<<"/"<<(int)tsarray[4]+1<<"/"<<(int)tsarray[5]+1900<<endl<<flush;
		cout<<"aquisition ended at "<<(int)tearray[0]<<":"<<(int)tearray[1]<<":"<<(int)tearray[2]<<"	"<<(int)tearray[3]<<"/"<<(int)tearray[4]+1<<"/"<<(int)tearray[5]+1900<<endl<<flush;
		cout <<"acquisition time was "<<(microseconds/1000000.0)<<" seconds"<<endl<<flush;
		outfile.write((char*)&tsarray,6);	 //saves starting timestamp 
		outfile.write((char*)&tearray,6);	 //saves ending timestamp
		out=write_from_array(sttm_off,33,1,channels); //stops hit state machine in frontend in selected channels
		cout<<"Address 33 (stop hit stt machine) status: "<<out<<endl<<flush;  //prints the write status (should be 0)
		*trigger_enable=0x00;	//disables central unit trigger (should be futile, it automatically stops after each trigger)		   
		outfile.close();		//close output file
		unmap_memory();		    //unmaps memory
		return 0;			    //returns 0 (everything was successful) 
	}
	else
	{
				cout<<"This program must receive exactly 4 arguments (enabled interface channels, trigger logic, number of events and output file name"<<endl<<flush;
	}
}
