#include <stdio.h>
#include <iostream>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

using namespace std;


int main(int argc, char *argv[]) {

  if (argc != 2) {
    cout<<"usage: ./trig-enabler [mode] (0=query trigger, 1=set trigger to 1)\n"<<flush;
    return 2;
  }

  int ret=0;
  int mode = strtoul(argv[1], NULL, 0);
  int mem_fd;
  void *base, *offset;
  long pagesize;

  pagesize = sysconf(_SC_PAGE_SIZE);

  if (pagesize <= 0) 
  {
    cout<<"invalid pagesize \n"<<flush;
    return 2;
  }

  mem_fd = open("/dev/mem", O_SYNC | O_RDWR);
  if (mem_fd < 0) {
    cout<<"open /dev/mem failed\n"<<flush;
    return 2;
  }

  base = mmap(NULL, 2*pagesize, PROT_READ | PROT_WRITE,
              MAP_SHARED, mem_fd, 0xFF20A010 & ~(pagesize-1));

  if (base == MAP_FAILED) {
    cout<<"mmap failed\n"<<flush;
    return 2;
  }
  offset = base + (0xFF20A010 & (pagesize-1));

  if(mode==0)
  {      
      ret=*(uint8_t*)offset;
  } 
  else if(mode==1)
  {
      *(uint8_t*)offset=1;
      ret=0;
  }
  else
  {
    cout<<"invalid mode \n"<<flush;
  }

  if (munmap(base, 2*pagesize)) 
  {
    cout<<"munmap failed\n"<<flush;
    return 2;
  }

  if (close(mem_fd)) 
  {
    cout<<"cannot close /dev/mem\n"<<flush;
    return 2;
  }
  return ret;
}
