python3.10 OSCILOSCOPE-ACQ.py
mv binario.bin tanque-1.bin
sleep 14
python3.10 OSCILOSCOPE-ACQ.py
mv binario.bin tanque-2.bin
sleep 14 
python3.10 OSCILOSCOPE-ACQ.py
mv binario.bin tanque-3.bin
sleep 14 
python3.10 OSCILOSCOPE-ACQ.py
mv binario.bin tanque-4.bin
sleep 14
python3.10 OSCILOSCOPE-ACQ.py
mv binario.bin tanque-5.bin
sleep 14
python3.10 OSCILOSCOPE-ACQ.py
mv binario.bin tanque-6.bin
sleep 14
python3.10 OSCILOSCOPE-ACQ.py
mv binario.bin tanque-7.bin
sleep 14
python3.10 OSCILOSCOPE-ACQ.py
mv binario.bin tanque-8.bin
sleep 14
python3.10 OSCILOSCOPE-ACQ.py
mv binario.bin tanque-9.bin
sleep 14
python3.10 OSCILOSCOPE-ACQ.py
mv binario.bin tanque-10.bin
sleep 14
python3.10 OSCILOSCOPE-ACQ.py
mv binario.bin tanque-11.bin
sleep 14
python3.10 OSCILOSCOPE-ACQ.py
mv binario.bin tanque-12.bin
sleep 14
python3.10 OSCILOSCOPE-ACQ.py
mv binario.bin tanque-13.bin
